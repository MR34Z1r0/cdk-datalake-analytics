from awsglue.context import GlueContext
from pyspark.sql import SparkSession, SQLContext
from pyspark.sql.types import *
from awsglue.utils import getResolvedOptions
from aje.get_schemas import *
from delta.tables import DeltaTable
from aje.get_schemas import *
import sys

spark = (
    SparkSession.builder.config(
        "spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog",
    )
    .config("spark.sql.legacy.parquet.int96RebaseModeInWrite", "CORRECTED")
    .getOrCreate()
)

sc = spark.sparkContext
glue_context = GlueContext(sc)
logger = glue_context.get_logger()
sqlContext = SQLContext(sparkSession=spark, sparkContext=sc)

######################################
# JOB PARAMETERS

args = getResolvedOptions(
    sys.argv,
    [
        "S3_PATH_DOM",
        "S3_PATH_COM",
    ],
)

S3_PATH_DOM = args["S3_PATH_DOM"]
S3_PATH_COM = args["S3_PATH_COM"]

######################################
# CREATE SCHEMA

schemas = SchemaDominioComercial(logger)
#schemas = SchemaModeloComercial(logger)

# table_list = [""]
table_list = schemas.dts_schemas
path = S3_PATH_DOM

for table_name in table_list:
    s3_path = f"{path}/{table_name}/"
    schema = schemas.get_schema(table_name)

    df = spark.createDataFrame([], schema)
    df.write.format("delta").option("overwriteSchema", "true").mode("overwrite").option(
        "mergeSchema", "true"
    ).save(s3_path)
    delta_table = DeltaTable.forPath(spark, s3_path)
    delta_table.generate("symlink_format_manifest")
