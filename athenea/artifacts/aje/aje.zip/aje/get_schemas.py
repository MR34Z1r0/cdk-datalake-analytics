from pyspark.sql.types import (
    DateType,
    IntegerType,
    StringType,
    DoubleType,
    DecimalType,
    TimestampType,
    StructField,
    StructType,
    BooleanType
)

class SchemaDominioComercial:
    def __init__(self, logger):
        self.logger = logger
        self.dts_schemas = {}

        self.dts_schemas["m_clasificacion_cliente"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_clasificacion_cliente", StringType(), True),
                StructField("id_clasificacion_cliente_padre", StringType(), True),
                StructField("cod_clasificacion_cliente", StringType(), True),
                StructField("nomb_clasificacion_cliente", StringType(), True),
                StructField("cod_tipo_clasificacion_cliente", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True)
            ]
        )

        # =========================================================================
        # m_articulo
        # Ajustes:
        #  - cant_cajas_por_palet, cant_paquete_caja, cant_unidad_paquete,
        #    cant_unidad_volumen: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["m_articulo"] = StructType([
            StructField("id_articulo", StringType(), True),
            StructField("id_pais", StringType(), True),
            StructField("id_articulo_ref", StringType(), True),
            StructField("cod_articulo", StringType(), True),
            StructField("cod_articulo_corp", StringType(), True),
            StructField("id_articulo_corp", StringType(), True),
            # Ojo: la columna "cod_articulo_ref" ya está repetida en el script;
            # si es un error tipográfico, podrías eliminar la duplicada
            StructField("cod_articulo_ref", StringType(), True),
            StructField("cod_articulo_ref2", StringType(), True),
            StructField("cod_articulo_ref3", StringType(), True),
            StructField("desc_articulo_corp", StringType(), True),
            StructField("desc_articulo", StringType(), True),
            StructField("cod_categoria", StringType(), True),
            StructField("desc_categoria", StringType(), True),
            StructField("cod_marca", StringType(), True),
            StructField("desc_marca", StringType(), True),
            StructField("cod_formato", StringType(), True),
            StructField("desc_formato", StringType(), True),
            StructField("cod_sabor", StringType(), True),
            StructField("desc_sabor", StringType(), True),
            StructField("cod_presentacion", StringType(), True),
            StructField("desc_presentacion", StringType(), True),
            StructField("cod_tipo_envase", StringType(), True),
            StructField("desc_tipo_envase", StringType(), True),
            StructField("cod_aroma", StringType(), True),
            StructField("desc_aroma", StringType(), True),
            StructField("cod_gasificado", StringType(), True),
            StructField("desc_gasificado", StringType(), True),
            StructField("cod_linea", StringType(), True),
            StructField("desc_linea", StringType(), True),
            StructField("flg_linea", StringType(), True),
            StructField("flg_explosion", StringType(), True),
            StructField("cod_familia", StringType(), True),
            StructField("desc_familia", StringType(), True),
            StructField("cod_subfamilia", StringType(), True),
            StructField("desc_subfamilia", StringType(), True),
            StructField("cod_unidad_negocio", StringType(), True),
            StructField("desc_unidad_negocio", StringType(), True),
            StructField("flg_jarabe", IntegerType(), True),
            StructField("flg_co2", IntegerType(), True),
            StructField("flg_azucar", IntegerType(), True),
            StructField("flg_jarabe_conver", IntegerType(), True),
            StructField("cod_unidad_compra", StringType(), True),
            StructField("cod_unidad_manejo", StringType(), True),
            StructField("cod_unidad_volumen", StringType(), True),
            StructField("cant_unidad_peso", StringType(), True),
            StructField("cant_unidad_volumen", DecimalType(38,12), True),   # se cambió
            StructField("cant_unidad_paquete", DecimalType(38,12), True),   # se cambió
            StructField("cant_paquete_caja", DecimalType(38,12), True),     # se cambió
            StructField("cant_cajas_por_palet", DecimalType(38,12), True),  # se cambió
            StructField("es_activo", StringType(), True),
            StructField("flgskuplan", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True)
        ])

        # =========================================================================
        # m_asignacion_modulo
        # Ajustes:
        #  - Columnas faltantes en Athena: periodo_visita, frecuencia_visita => StringType() # faltaba
        # =========================================================================
        self.dts_schemas["m_asignacion_modulo"] = StructType([
            StructField("id_asignacion_modulo", StringType(), True),
            StructField("id_pais", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_cliente", StringType(), True),
            StructField("id_modulo", StringType(), True),
            StructField("fecha_inicio", TimestampType(), True),
            StructField("fecha_fin", TimestampType(), True),
            StructField("es_activo", IntegerType(), True),
            StructField("es_eliminado", IntegerType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
            StructField("periodo_visita", StringType(), True),    # faltaba
            StructField("frecuencia_visita", StringType(), True)  # faltaba
        ])

        # =========================================================================
        # m_cliente
        # Ajustes:
        #  - Columnas faltantes: cod_cliente_ref2, cod_cliente_ref, cod_cliente_ref4,
        #    cod_cliente_ref3, id_lista_precio, periodo_visita, frecuencia_visita,
        #    desc_subsegmento => StringType() # faltaba
        # =========================================================================
        self.dts_schemas["m_cliente"] = StructType([
            StructField("id_cliente", StringType(), True),
            StructField("id_cliente_ref", StringType(), True),
            StructField("id_cliente_ref2", StringType(), True),
            StructField("id_pais", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_eje_territorial", StringType(), True),
            StructField("id_clasificacion_cliente", StringType(), True),
            StructField("cod_cliente", StringType(), True),
            StructField("nomb_cliente", StringType(), True),
            StructField("cod_cuenta_clave", StringType(), True),
            StructField("nomb_cuenta_clave", StringType(), True),
            StructField("cod_segmento", StringType(), True),
            StructField("desc_canal_local", StringType(), True),
            StructField("desc_giro_local", StringType(), True),
            StructField("direccion", StringType(), True),
            StructField("tipo_documento", StringType(), True),
            StructField("nro_documento", StringType(), True),
            StructField("cod_tipo_cliente", StringType(), True),
            StructField("cod_cliente_principal", StringType(), True),
            StructField("cod_cliente_transferencia", StringType(), True),
            StructField("coord_x", StringType(), True),
            StructField("coord_y", StringType(), True),
            StructField("fecha_baja", DateType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
            #
            StructField("cod_cliente_ref2", StringType(), True),    # faltaba
            StructField("cod_cliente_ref", StringType(), True),     # faltaba
            StructField("cod_cliente_ref4", StringType(), True),    # faltaba
            StructField("cod_cliente_ref3", StringType(), True),    # faltaba
            StructField("id_lista_precio", StringType(), True),     # faltaba
            # StructField("periodo_visita", StringType(), True),      # faltaba
            # StructField("frecuencia_visita", StringType(), True),   # faltaba
            StructField("desc_subsegmento", StringType(), True)     # faltaba
        ])

        self.dts_schemas["m_eje_territorial"] = StructType(
            [
                StructField("id_eje_territorial", StringType(), True),
                StructField("id_eje_territorial_padre", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_eje_territorial", StringType(), True),
                StructField("cod_eje_territorial_ref", StringType(), True),
                StructField("nomb_eje_territorial", StringType(), True),
                StructField("cod_tipo_eje_territorial", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True)
            ]
        )

        self.dts_schemas["m_compania"] = StructType(
            [
                StructField("id_compania", StringType(), True),
                StructField("id_compania_ref", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_compania", StringType(), True),
                StructField("nomb_compania", StringType(), True),
                StructField("cod_tipo_compania", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )

        self.dts_schemas["m_forma_pago"] = StructType(
            [
                StructField("id_forma_pago", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_forma_pago", StringType(), True),
                StructField("nomb_forma_pago", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )

        self.dts_schemas["m_fuerza_venta"] = StructType(
            [
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_fuerza_venta", StringType(), True),
                StructField("nomb_fuerza_venta", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True)
            ]
        )

        self.dts_schemas["m_lista_precio"] = StructType(
            [
                StructField("id_lista_precio", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_lista_precio", StringType(), True),
                StructField("nomb_lista_precio", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True)
            ]
        )

        self.dts_schemas["m_estructura_comercial"] = StructType(
            [
                StructField("id_estructura_comercial", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_estructura_comercial_padre", StringType(), True),
                StructField("id_responsable_comercial", StringType(), True),
                StructField("cod_estructura_comercial", StringType(), True),
                StructField("nomb_estructura_comercial", StringType(), True),
                StructField("cod_tipo_estructura_comercial", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True)
            ]
        )
        # =========================================================================
        # m_modulo
        # Ajustes:
        #  - Columna faltante en Athena: desc_fuerza_venta => StringType() # faltaba
        # =========================================================================
        self.dts_schemas["m_modulo"] = StructType([
            StructField("id_modulo", StringType(), True),
            StructField("id_pais", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_estructura_comercial", StringType(), True),
            StructField("id_modelo_atencion", StringType(), True),
            StructField("cod_modulo", StringType(), True),
            StructField("desc_modulo", StringType(), True),
            StructField("periodo_visita", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
            StructField("desc_fuerza_venta", StringType(), True)  # faltaba
        ])

        self.dts_schemas["m_origen_pedido"] = StructType(
            [
                StructField("id_origen_pedido", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_origen_pedido", StringType(), True),
                StructField("nomb_origen_pedido", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )

        self.dts_schemas["m_pais"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("cod_pais", StringType(), True),
                StructField("desc_pais", StringType(), True),
                StructField("desc_pais_comercial", StringType(), True),
                StructField("desc_continente", StringType(), True)
            ]
        )

        self.dts_schemas["m_sucursal"] = StructType(
            [
                StructField("id_sucursal", StringType(), True),
                StructField("id_sucursal_ref", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_sucursal", StringType(), True),
                StructField("nomb_sucursal", StringType(), True),
                StructField("cod_tipo_sucursal", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )

        self.dts_schemas["m_tipo_pedido"] = StructType(
            [
                StructField("id_tipo_pedido", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_tipo_pedido", StringType(), True),
                StructField("nomb_tipo_pedido", StringType(), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
            ]
        )

        self.dts_schemas["m_tipo_venta"] = StructType(
            [
                StructField("id_tipo_venta", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_tipo_venta", StringType(), True),
                StructField("nomb_tipo_venta", StringType(), True),
                StructField("cod_tipo_operacion", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )

        self.dts_schemas["m_responsable_comercial"] = StructType(
            [
                StructField("id_responsable_comercial", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_responsable_comercial", StringType(), True),
                StructField("nomb_responsable_comercial", StringType(), True),
                StructField("cod_tipo_responsable_comercial", StringType(), True),
                StructField("estado", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )


        # =========================================================================
        # t_avance_dia
        # Ajustes principales:
        #  - Faltan columnas: cu_totales_vendedor_ecommerce__c, cajas_totales_vendedor_ecommerce__c (Redshift=numeric)
        #    => DecimalType(38,12) # faltaba
        #  - Varias columnas numeric vs double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_avance_dia"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_avance_dia", StringType(), True),
            StructField("id_vendedor", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_modelo_atencion", StringType(), True),
            StructField("cod_avance_dia", StringType(), True),
            StructField("cod_unidad", StringType(), True),
            StructField("cod_modulo", StringType(), True),
            StructField("desc_modulo", StringType(), True),
            StructField("cod_ruta", StringType(), True),
            StructField("desc_ruta", StringType(), True),
            StructField("cod_zona", StringType(), True),
            StructField("desc_zona", StringType(), True),
            StructField("fecha_avance_dia", DateType(), True),
            StructField("fecha_inicio", TimestampType(), True),
            StructField("fecha_fin", TimestampType(), True),
            StructField("coordx_inicio", StringType(), True),
            StructField("coordx_fin", StringType(), True),
            StructField("coordy_inicio", StringType(), True),
            StructField("coordy_fin", StringType(), True),
            StructField("distancia_recorrida", DecimalType(38,12), True),  # se cambió
            StructField("cant_cuota_cambio", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True),
            StructField("avance_cajas_unitarias__c", StringType(), True),
            StructField("avance_cajas__c", DecimalType(38,12), True),      # se cambió
            StructField("avance_del_dia__c", DecimalType(38,12), True),    # se cambió
            StructField("avance_del_mes__c", StringType(), True),
            StructField("avance_importe__c", DecimalType(38,12), True),    # se cambió
            StructField("bateria__c", StringType(), True),
            StructField("cajas_totales_cliente_nuevo__c", DecimalType(38,12), True),  # se cambió
            StructField("cajas_totales_extra_ruta__c", DecimalType(38,12), True),     # se cambió
            StructField("cajas_totales_prospecto__c", DecimalType(38,12), True),      # se cambió
            StructField("cajas_totales_vendedor__c", DecimalType(38,12), True),       # se cambió
            StructField("cajas_totales__c", DecimalType(38,12), True),                # se cambió
            StructField("categorias__c", StringType(), True),
            StructField("clientes_compra_0__c", DecimalType(38,12), True),            # se cambió
            StructField("clientes_compra__c", DecimalType(38,12), True),              # se cambió
            StructField("clientes_visitados__c", DecimalType(38,12), True),           # se cambió
            StructField("codigo_unico_vendedor__c", StringType(), True),
            StructField("codigo_vendedor__c", StringType(), True),
            StructField("compania__c", StringType(), True),
            StructField("createdbyid", StringType(), True),
            StructField("createddate", TimestampType(), True),
            StructField("cuota_de_cambio__c", DecimalType(38,12), True),   # se cambió
            StructField("cuota_de_ruta__c", StringType(), True),
            StructField("currencyisocode", StringType(), True),
            StructField("device_id__c", StringType(), True),
            StructField("diferencia_clientes_compra_total_pedidos__c", BooleanType(), True),
            StructField("drop_size__c", DecimalType(38,12), True),         # se cambió
            StructField("efectividad__c", DecimalType(38,12), True),       # se cambió
            StructField("enviar_a_call_center__c", BooleanType(), True),
            StructField("fecha_fin_dia__c", DateType(), True),
            StructField("fecha_hora_primer_pedido__c", TimestampType(), True),
            StructField("fecha_hora_primer_visita__c", TimestampType(), True),
            StructField("fecha_hora_ultima_sincronizacion__c", TimestampType(), True),
            StructField("fecha_hora_ultima_visita_c__c", TimestampType(), True),
            StructField("fecha_hora_ultimo_pedido__c", TimestampType(), True),
            StructField("fecha_inicio_dia__c", DateType(), True),
            StructField("fecha_vendedor__c", StringType(), True),
            StructField("fecha__c", TimestampType(), True),
            StructField("fin_de_dia__c", StringType(), True),
            StructField("fuerza_de_venta__c", StringType(), True),
            StructField("hora_fin_dia__c", StringType(), True),
            StructField("hora_inicio_dia__c", StringType(), True),
            StructField("id", StringType(), True),
            StructField("id_agente__c", StringType(), True),
            StructField("inicio_de_dia__c", StringType(), True),
            StructField("isdeleted", BooleanType(), True),
            StructField("kpi_cajas__c", StringType(), True),
            StructField("kpi_cobertura_simple__c", StringType(), True),
            StructField("kpi_importe__c", StringType(), True),
            StructField("lastactivitydate", TimestampType(), True),
            StructField("lastmodifiedbyid", StringType(), True),
            StructField("lastmodifieddate", TimestampType(), True),
            StructField("lastreferenceddate", TimestampType(), True),
            StructField("lastvieweddate", TimestampType(), True),
            StructField("latitud_fin__c", StringType(), True),
            StructField("latitud__c", StringType(), True),
            StructField("longitud_fin__c", StringType(), True),
            StructField("longitud__c", StringType(), True),
            StructField("marcas__c", StringType(), True),
            StructField("modelo_atencion__c", StringType(), True),
            StructField("modulo__c", StringType(), True),
            StructField("name", StringType(), True),
            StructField("necesidad_cu_diaria__c", DecimalType(38,12), True),          # se cambió
            StructField("necesidad_diaria_importe__c", DecimalType(38,12), True),     # se cambió
            StructField("necesidad_diaria__c", DecimalType(38,12), True),             # se cambió
            StructField("nombre_region__c", StringType(), True),
            StructField("nombre_subregion__c", StringType(), True),
            StructField("nombre_vendedor__c", StringType(), True),
            StructField("numero__c", StringType(), True),
            StructField("ownerid", StringType(), True),
            StructField("pais__c", StringType(), True),
            StructField("portafolio__c", StringType(), True),
            StructField("region__c", StringType(), True),
            StructField("rutan__c", StringType(), True),
            StructField("ruta__c", StringType(), True),
            StructField("subregion__c", StringType(), True),
            StructField("sucursal__c", StringType(), True),
            StructField("systemmodstamp", StringType(), True),
            StructField("telefono_vendedor__c", StringType(), True),
            StructField("total_cajas_cliente_nuevo__c", DecimalType(38,12), True),    # se cambió
            StructField("total_cajas_extra_ruta__c", DecimalType(38,12), True),       # se cambió
            StructField("total_cajas_fisicas__c", DecimalType(38,12), True),          # se cambió
            StructField("total_cajas_prospectos__c", DecimalType(38,12), True),       # se cambió
            StructField("total_cajas_vendedor__c", DecimalType(38,12), True),         # se cambió
            StructField("total_clientes_activos__c", DecimalType(38,12), True),       # se cambió
            StructField("total_clientes_compra2__c", DecimalType(38,12), True),       # se cambió
            StructField("total_clientes__c", DecimalType(38,12), True),               # se cambió
            StructField("total_de_cajas__c", DecimalType(38,12), True),               # se cambió
            StructField("total_de_caja_unidades__c", DecimalType(38,12), True),       # se cambió
            StructField("total_importe_cliente_nuevo__c", DecimalType(38,12), True),  # se cambió
            StructField("total_importe_extra_ruta__c", DecimalType(38,12), True),     # se cambió
            StructField("total_importe_prospecto__c", DecimalType(38,12), True),      # se cambió
            StructField("total_importe_vendedor__c", DecimalType(38,12), True),       # se cambió
            StructField("total_importe__c", DecimalType(38,12), True),                # se cambió
            StructField("total_no_pedidos__c", DecimalType(38,12), True),             # se cambió
            StructField("total_pedidos_cliente_nuevo__c", DecimalType(38,12), True),  # se cambió
            StructField("total_pedidos_extra_ruta__c", DecimalType(38,12), True),     # se cambió
            StructField("total_pedidos_prospecto__c", DecimalType(38,12), True),      # se cambió
            StructField("total_pedidos__c", DecimalType(38,12), True),                # se cambió
            StructField("total_skus_cliente_nuevo__c", DecimalType(38,12), True),     # se cambió
            StructField("total_skus_extra_ruta__c", DecimalType(38,12), True),        # se cambió
            StructField("total_skus_prospecto__c", DecimalType(38,12), True),         # se cambió
            StructField("total_skus__c", DecimalType(38,12), True),                   # se cambió
            StructField("total_unidades_cliente_nuevo__c", DecimalType(38,12), True), # se cambió
            StructField("total_unidades_extra_ruta__c", DecimalType(38,12), True),    # se cambió
            StructField("total_unidades_prospecto__c", DecimalType(38,12), True),     # se cambió
            StructField("total_unidades__c", DecimalType(38,12), True),               # se cambió
            StructField("unidades_cambiadas__c", DecimalType(38,12), True),           # se cambió
            StructField("vendedor_volante__c", StringType(), True),
            StructField("vendedor__c", StringType(), True),
            StructField("version_app__c", StringType(), True),
            StructField("version_del_app__c", StringType(), True),
            StructField("zonan__c", StringType(), True),
            StructField("zona__c", StringType(), True),
            StructField("cu_totales_vendedor__c", DecimalType(38,12), True),
            StructField("efectividad_preventa_ecommerce__c", DecimalType(38,12), True),
            StructField("efectividad_visita_ecommerce__c", DecimalType(38,12), True),            
            StructField("cu_totales_vendedor_ecommerce__c", DecimalType(38,12), True),   # faltaba
            StructField("cajas_totales_vendedor_ecommerce__c", DecimalType(38,12), True) # faltaba
        ])

        # =========================================================================
        # t_pedido_detalle
        # Ajustes:
        #  - Columnas faltantes: desc_promocion, cod_promocion, fuente => StringType() # faltaba
        #  - Varias columnas numeric vs double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_pedido_detalle"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_pedido", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("cant_cajafisica_ped", DecimalType(38, 12), True),             # se cambió
            StructField("cant_cajavolumen_ped", DecimalType(38, 12), True),            # se cambió
            StructField("cant_cajafisica_ped_pro", DecimalType(38, 12), True),         # se cambió
            StructField("cant_cajavolumen_ped_pro", DecimalType(38, 12), True),        # se cambió
            StructField("cant_cajafisica_asignado_ped", DecimalType(38, 12), True),    # se cambió
            StructField("cant_cajavolumen_asignado_ped", DecimalType(38, 12), True),   # se cambió
            StructField("cant_cajafisica_asignado_ped_pro", DecimalType(38, 12), True),# se cambió
            StructField("cant_cajavolumen_asignado_ped_pro", DecimalType(38, 12), True),# se cambió
            StructField("imp_bruto_ped_mn", DecimalType(38, 12), True),                # se cambió
            StructField("imp_bruto_ped_me", DecimalType(38, 12), True),                # se cambió
            StructField("imp_dscto_ped_mn", DecimalType(38, 12), True),                # se cambió
            StructField("imp_dscto_ped_me", DecimalType(38, 12), True),                # se cambió
            StructField("imp_neto_ped_mn", DecimalType(38, 12), True),                 # se cambió
            StructField("imp_neto_ped_me", DecimalType(38, 12), True),                 # se cambió
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
            StructField("es_eliminado", IntegerType(), True),
            # StructField("desc_promocion", StringType(), True),  # faltaba
            # StructField("cod_promocion", StringType(), True),    # faltaba
            # StructField("fuente", StringType(), True)            # faltaba
        ])

        # =========================================================================
        # t_pedido
        # Ajustes:
        #  - Columna faltante en Athena: fuente (character varying) => StringType() # faltaba
        #  - tipo_cambio_mn y tipo_cambio_me: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_pedido"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_pedido", StringType(), True),
            StructField("id_pedido_ref", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_visita", StringType(), True),
            StructField("id_cliente", StringType(), True),
            StructField("id_modelo_atencion", StringType(), True),
            StructField("id_origen_pedido", StringType(), True),
            StructField("id_tipo_pedido", StringType(), True),
            StructField("id_fuerza_venta", StringType(), True),
            StructField("id_vendedor", StringType(), True),
            StructField("id_supervisor", StringType(), True),
            StructField("id_jefe_venta", StringType(), True),
            StructField("id_lista_precio", StringType(), True),
            StructField("id_forma_pago", StringType(), True),
            StructField("desc_region", StringType(), True),
            StructField("desc_subregion", StringType(), True),
            StructField("desc_division", StringType(), True),
            StructField("desc_estado", StringType(), True),
            StructField("cod_zona", StringType(), True),
            StructField("cod_ruta", StringType(), True),
            StructField("cod_modulo", StringType(), True),
            StructField("cod_pedido_salesforce", StringType(), True),
            StructField("cod_pedido_sugerido", StringType(), True),
            StructField("es_pedido_sugerido", IntegerType(), True),
            StructField("es_prospecto", IntegerType(), True),
            StructField("es_extramodulo", IntegerType(), True),
            StructField("cod_tipo_atencion", StringType(), True),
            StructField("fecha_pedido", DateType(), True),
            StructField("fecha_entrega", DateType(), True),
            StructField("fecha_visita", DateType(), True),
            StructField("nro_pedido", StringType(), True),
            StructField("cod_motivo_no_pedido", StringType(), True),
            StructField("fecha_no_pedido", TimestampType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
            StructField("es_eliminado", IntegerType(), True),
            StructField("tipo_cambio_mn", DecimalType(38, 12), True),  # se cambió
            StructField("tipo_cambio_me", DecimalType(38, 12), True),  # se cambió
            #StructField("fuente", StringType(), True)                  # faltaba
        ])

        # =========================================================================
        # t_venta_detalle
        # Ajustes:
        #  - Todas las columnas numeric vs double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_venta_detalle"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_venta", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("cant_caja_fisica_ven", DecimalType(38,12), True),      # se cambió
            StructField("cant_caja_fisica_pro", DecimalType(38,12), True),      # se cambió
            StructField("cant_caja_volumen_ven", DecimalType(38,12), True),     # se cambió
            StructField("cant_caja_volumen_pro", DecimalType(38,12), True),     # se cambió
            StructField("imp_neto_vta_mn", DecimalType(38,12), True),           # se cambió
            StructField("imp_neto_vta_me", DecimalType(38,12), True),           # se cambió
            StructField("imp_bruto_vta_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_bruto_vta_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_dscto_mn", DecimalType(38,12), True),              # se cambió
            StructField("imp_dscto_me", DecimalType(38,12), True),              # se cambió
            StructField("imp_dscto_sinimpvta_mn", DecimalType(38,12), True),    # se cambió
            StructField("imp_dscto_sinimpvta_me", DecimalType(38,12), True),    # se cambió
            StructField("imp_cobrar_vta_mn", DecimalType(38,12), True),         # se cambió
            StructField("imp_cobrar_vta_me", DecimalType(38,12), True),         # se cambió
            StructField("imp_paquete_vta_mn", DecimalType(38,12), True),        # se cambió
            StructField("imp_paquete_vta_me", DecimalType(38,12), True),        # se cambió
            StructField("imp_sugerido_mn", DecimalType(38,12), True),           # se cambió
            StructField("imp_sugerido_me", DecimalType(38,12), True),           # se cambió
            StructField("imp_full_vta_mn", DecimalType(38,12), True),           # se cambió
            StructField("imp_full_vta_me", DecimalType(38,12), True),           # se cambió
            StructField("imp_valorizado_pro_mn", DecimalType(38,12), True),     # se cambió
            StructField("imp_valorizado_pro_me", DecimalType(38,12), True),     # se cambió
            StructField("imp_impuesto1_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto1_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto2_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto2_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto3_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto3_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto4_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto4_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto5_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto5_me", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto6_mn", DecimalType(38,12), True),          # se cambió
            StructField("imp_impuesto6_me", DecimalType(38,12), True),          # se cambió
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)
        ])

        # =========================================================================
        # t_venta
        # Ajustes:
        #  - Columna faltante: nro_venta_ref => StringType() # faltaba
        #  - tipo_cambio_me, tipo_cambio_mn: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_venta"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_venta", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_pedido", StringType(), True),
            StructField("id_tipo_venta", StringType(), True),
            StructField("id_cliente", StringType(), True),
            StructField("id_fuerza_venta", StringType(), True),
            StructField("id_vendedor", StringType(), True),
            StructField("id_supervisor", StringType(), True),
            StructField("id_jefe_venta", StringType(), True),
            StructField("id_lista_precio", StringType(), True),
            StructField("id_tipo_documento", StringType(), True),
            StructField("id_forma_pago", StringType(), True),
            StructField("fecha_liquidacion", DateType(), True),
            StructField("fecha_emision", DateType(), True),
            StructField("cod_documento_venta", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True),
            StructField("tipo_cambio_mn", DecimalType(38, 12), True),  # se cambió
            StructField("tipo_cambio_me", DecimalType(38, 12), True),  # se cambió
            StructField("es_anulado", IntegerType(), True),
            StructField("id_motivo_rechazo", StringType(), True),
            StructField("id_tipo_documento_venta", StringType(), True),
            StructField("id_motivo_nota_credito", StringType(), True),
            StructField("nro_venta", StringType(), True),
            StructField("desc_region", StringType(), True),
            StructField("desc_subregion", StringType(), True),
            StructField("desc_division", StringType(), True),
            StructField("cod_zona", StringType(), True),
            StructField("cod_ruta", StringType(), True),
            StructField("cod_modulo", StringType(), True),
            StructField("nro_venta_ref", StringType(), True)  # faltaba
        ])
        # =========================================================================
        # t_visita
        # Ajustes:
        #  - cant_total_unidades_cambio, cant_total_unidades, cant_total_skus,
        #    cant_total_pedidos, cant_total_litros, imp_total,
        #    cant_total_cajas_fisicas, cant_total_cajas: Redshift=numeric vs Athena=double
        #    => DecimalType(38,12) # se cambió
        # (fecha_check_in / fecha_check_out difieren en logs pero no hay instrucción concreta)
        # =========================================================================
        self.dts_schemas["t_visita"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_visita", StringType(), True),
            StructField("id_avance_dia", StringType(), True),
            StructField("id_cliente", StringType(), True),
            StructField("id_visita_anterior", StringType(), True),
            StructField("cod_visita", StringType(), True),
            StructField("fecha_visita", DateType(), True),
            StructField("fecha_inicio", TimestampType(), True),
            StructField("fecha_fin", TimestampType(), True),
            StructField("tiempo_visita_transcurrido", StringType(), True),
            StructField("secuencia", StringType(), True),
            StructField("es_activo", IntegerType(), True),
            StructField("es_programado", IntegerType(), True),
            StructField("es_pedido_sugerido", IntegerType(), True),
            StructField("es_visita_auto", IntegerType(), True),
            StructField("desc_motivo_no_pedido", StringType(), True),
            StructField("coordx", StringType(), True),
            StructField("coordy", StringType(), True),
            StructField("distancia_fin", StringType(), True),
            StructField("tiempo_visita", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True),
            StructField("fecha_check_in", StringType(), True),
            StructField("fecha_check_out", StringType(), True),
            StructField("es_check_out_automatico", IntegerType(), True),
            StructField("es_pedido_levantado", IntegerType(), True),
            StructField("cant_total_cajas", DecimalType(38,12), True),             # se cambió
            StructField("cant_total_cajas_fisicas", DecimalType(38,12), True),     # se cambió
            StructField("imp_total", DecimalType(38,12), True),                    # se cambió
            StructField("cant_total_litros", DecimalType(38,12), True),            # se cambió
            StructField("cant_total_pedidos", DecimalType(38,12), True),           # se cambió
            StructField("cant_total_skus", DecimalType(38,12), True),              # se cambió
            StructField("cant_total_unidades", DecimalType(38,12), True),          # se cambió
            StructField("cant_total_unidades_cambio", DecimalType(38,12), True)    # se cambió
        ])

        self.dts_schemas["m_modelo_atencion"] = StructType(
            [
                StructField("id_modelo_atencion", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_modelo_atencion", StringType(), True),
                StructField("desc_modelo_atencion", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )


    def get_schema(self, table_name):
        if table_name in self.dts_schemas:
            return self.dts_schemas[table_name]
        else:
            self.logger(f"{table_name} schema not found")
            return None

class SchemaModeloComercial:
    def __init__(self, logger):
        self.logger = logger
        self.dts_schemas = {}

        self.dts_schemas["dim_clasificacion_cliente"] = StructType(
            [
                StructField("id_clasificacion_cliente", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_subgiro", StringType(), True),
                StructField("desc_subgiro", StringType(), True),
                StructField("cod_ocasion_consumo", StringType(), True),
                StructField("desc_ocasion_consumo", StringType(), True),
                StructField("cod_giro", StringType(), True),
                StructField("desc_giro", StringType(), True),
                StructField("cod_canal", StringType(), True),
                StructField("desc_canal", StringType(), True),
            ]
        )

        self.dts_schemas["dim_cliente"] = StructType(
            [
                StructField("id_cliente", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_estructura_comercial", StringType(), True),
                StructField("id_clasificacion_cliente", StringType(), True),
                StructField("id_eje_territorial", StringType(), True),
                StructField("id_lista_precio", StringType(), True),  # new
                StructField("cod_cliente", StringType(), True),
                StructField("nomb_cliente", StringType(), True),
                StructField("cod_segmento", StringType(), True),
                StructField("desc_subsegmento", StringType(), True),  # new
                StructField("cod_cliente_ref", StringType(), True),  # new
                StructField("cod_cliente_ref2", StringType(), True),  # new
                StructField("cod_cliente_ref3", StringType(), True),  # new
                StructField("cod_cliente_ref4", StringType(), True),  # new
                StructField("frecuencia_visita", StringType(), True),  # new
                StructField("periodo_visita", StringType(), True),  # new
                StructField("cod_tipo_cliente", StringType(), True),
                StructField("cod_cuenta_clave", StringType(), True),
                StructField("nomb_cuenta_clave", StringType(), True),
                StructField("desc_canal_local", StringType(), True),
                StructField("desc_giro_local", StringType(), True),
                StructField("direccion", StringType(), True),
                StructField("ruc", StringType(), True),
                StructField("cod_cliente_principal", StringType(), True),
                StructField("cod_cliente_transferencia", StringType(), True),
                StructField("zona_postal", StringType(), True),
                StructField("coordx", StringType(), True),
                StructField("coordy", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_baja", DateType(), True),
                StructField("estado", StringType(), True)
            ]
        )

        self.dts_schemas["dim_eje_territorial"] = StructType(
            [
                StructField("id_eje_territorial", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_pais", StringType(), True),
                StructField("desc_pais", StringType(), True),
                StructField("cod_ng1", StringType(), True),
                StructField("desc_ng1", StringType(), True),
                StructField("cod_ng2", StringType(), True),
                StructField("desc_ng2", StringType(), True),
                StructField("cod_ng3", StringType(), True),
                StructField("desc_ng3", StringType(), True),
                StructField("cod_ng4", StringType(), True),
                StructField("desc_ng4", StringType(), True),
                StructField("zona_postal", StringType(), True)
            ]
        )

        self.dts_schemas["dim_estructura_comercial"] = StructType(
            [
                StructField("id_estructura_comercial", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_fuerza_venta", StringType(), True),
                StructField("cod_modelo_atencion", StringType(), True),
                StructField("cod_pais", StringType(), True),
                StructField("cod_region", StringType(), True),
                StructField("cod_subregion", StringType(), True),
                StructField("cod_division", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("cod_vendedor", StringType(), True),
                StructField("nomb_vendedor", StringType(), True),
                StructField("cod_supervisor", StringType(), True),
                StructField("nomb_supervisor", StringType(), True),
                StructField("cod_jefe_venta", StringType(), True),
                StructField("nomb_jefe_venta", StringType(), True),
                StructField("desc_fuerza_venta", StringType(), True),
                StructField("desc_modelo_atencion", StringType(), True),
                StructField("desc_region", StringType(), True),
                StructField("desc_subregion", StringType(), True),
                StructField("desc_division", StringType(), True),
                StructField("desc_zona", StringType(), True),
                StructField("desc_ruta", StringType(), True),
                StructField("desc_modulo", StringType(), True)
            ]
        )

        self.dts_schemas["dim_forma_pago"] = StructType(
            [
                StructField("id_forma_pago", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_forma_pago", StringType(), True),
                StructField("desc_forma_pago", StringType(), True)
            ]
        )

        self.dts_schemas["dim_fuerza_venta"] = StructType(
            [
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_fuerza_venta", StringType(), True),
                StructField("desc_fuerza_venta", StringType(), True)
            ]
        )

        self.dts_schemas["dim_lista_precio"] = StructType(
            [
                StructField("id_lista_precio", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_lista_precio", StringType(), True),
                StructField("desc_lista_precio", StringType(), True)
            ]
        )

        self.dts_schemas["dim_origen_pedido"] = StructType(
            [
                StructField("id_origen_pedido", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_origen_pedido", StringType(), True),
                StructField("desc_origen_pedido", StringType(), True)
            ]
        )

        self.dts_schemas["dim_pais"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("cod_pais", StringType(), True),
                StructField("desc_pais", StringType(), True),
                StructField("desc_pais_comercial", StringType(), True),
                StructField("desc_continente", StringType(), True)
            ]
        )

        self.dts_schemas["dim_producto"] = StructType(
            [
                StructField("id_producto", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_producto", StringType(), True),
                StructField("desc_producto", StringType(), True),
                StructField("desc_producto_corporativo", StringType(), True),
                StructField("cod_categoria", StringType(), True),
                StructField("desc_categoria", StringType(), True),
                StructField("cod_marca", StringType(), True),
                StructField("desc_marca", StringType(), True),
                StructField("cod_presentacion", StringType(), True),
                StructField("desc_presentacion", StringType(), True),
                StructField("cod_formato", StringType(), True),
                StructField("desc_formato", StringType(), True),
                StructField("cod_sabor", StringType(), True),
                StructField("desc_sabor", StringType(), True),
                StructField("cod_tipo_envase", StringType(), True),
                StructField("desc_tipo_envase", StringType(), True),
                StructField("cod_unidad_paquete", StringType(), True),
                StructField("cod_unidad_volumen", StringType(), True),
                StructField("cant_unidad_paquete", DecimalType(38,12), True),
                StructField("cant_unidad_volumen", DecimalType(38,12), True),
                StructField("es_activo", StringType(), True),
                StructField("cod_unidad_negocio", StringType(), True),
                StructField("desc_unidad_negocio", StringType(), True),
            ]
        )

        self.dts_schemas["dim_sucursal"] = StructType(
            [
                StructField("id_sucursal", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_compania", StringType(), True),
                StructField("desc_compania", StringType(), True),
                StructField("cod_tipo_compania", StringType(), True),
                StructField("cod_sucursal", StringType(), True),
                StructField("desc_sucursal", StringType(), True),
                StructField("cod_tipo_sucursal", StringType(), True)
            ]
        )

        self.dts_schemas["dim_tipo_pedido"] = StructType(
            [
                StructField("id_tipo_pedido", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_tipo_pedido", StringType(), True),
                StructField("desc_tipo_pedido", StringType(), True),
            ]
        )

        self.dts_schemas["dim_tipo_venta"] = StructType(
            [
                StructField("id_tipo_venta", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_tipo_venta", StringType(), True),
                StructField("cod_subtipo_venta", StringType(), True),
                StructField("desc_tipo_venta", StringType(), True),
                StructField("desc_subtipo_venta", StringType(), True),
            ]
        )

        self.dts_schemas["dim_vendedor"] = StructType(
            [
                StructField("id_vendedor", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_vendedor", StringType(), True),
                StructField("nombre_vendedor", StringType(), True)
            ]
        )

        self.dts_schemas["dim_transportista"] = StructType(
            [
                StructField("id_transportista", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_transportista", StringType(), True),
                StructField("nomb_transportista", StringType(), True),
                StructField("cod_tipo_transportista", StringType(), True),
                StructField("desc_tipo_transportista", StringType(), True),
                StructField("ruc_transportista", StringType(), True),
            ]
        )

        self.dts_schemas["dim_medio_transporte"] = StructType(
            [
                StructField("id_medio_transporte", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_medio_transporte", StringType(), True),
                StructField("cod_tipo_medio_transporte", StringType(), True),
                StructField("desc_tipo_medio_transporte", StringType(), True),
                StructField("desc_marca_medio_transporte", StringType(), True),
                StructField("cod_tipo_capacidad", StringType(), True),
                StructField("cant_peso_maximo", IntegerType(), True),
                StructField("cant_tarimas", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )
        self.dts_schemas["fact_cliente_venta"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("fecha_periodo", DateType(), True),  # new
                StructField("cant_caja_fisica_ven_3meses", DecimalType(38,12), True),
                StructField("cant_caja_fisica_ven_12meses", DecimalType(38,12), True),
                StructField("cant_caja_unitaria_ven_3meses", DecimalType(38,12), True),
                StructField("cant_caja_unitaria_ven_12meses", DecimalType(38,12), True),
                StructField("cant_caja_fisica_pro_3meses", DecimalType(38,12), True),
                StructField("cant_caja_fisica_pro_12meses", DecimalType(38,12), True),
                StructField("cant_caja_unitaria_pro_3meses", DecimalType(38,12), True),
                StructField("cant_caja_unitaria_pro_12meses", DecimalType(38,12), True),
                StructField("imp_neto_mn_3meses", DecimalType(38,12), True),
                StructField("imp_neto_mn_12meses", DecimalType(38,12), True),
                StructField("imp_neto_me_3meses", DecimalType(38,12), True),
                StructField("imp_neto_me_12meses", DecimalType(38,12), True),
                StructField("imp_bruto_mn_3meses", DecimalType(38,12), True),
                StructField("imp_bruto_mn_12meses", DecimalType(38,12), True),
                StructField("imp_bruto_me_3meses", DecimalType(38,12), True),
                StructField("imp_bruto_me_12meses", DecimalType(38,12), True),
                StructField("cant_producto", IntegerType(), True),
                StructField("cant_venta", IntegerType(), True),
                StructField("cant_marca", IntegerType(), True),
                StructField("ult_fecha_compra_cliente", DateType(), True),
                StructField("ult_dia_compra_cliente", IntegerType(), True),
                StructField("cant_caja_unit_venta_12meses_nn", DecimalType(38,12), True),
                StructField("cant_caja_unit_venta_3meses_nn", DecimalType(38,12), True),
                StructField("imp_neto_mn_12meses_nn", DecimalType(38,12), True),
                StructField("imp_neto_mn_3meses_nn", DecimalType(38,12), True),
                StructField("ult_fecha_compra_12meses_nn", DateType(), True),
                StructField("cant_venta_nn", IntegerType(), True),
                StructField("cant_marca_nn", IntegerType(), True),
                StructField("cant_marca_12meses", IntegerType(), True),  # new
                StructField("cant_marca_3meses", IntegerType(), True),  # new
                StructField("cant_venta_12meses", IntegerType(), True),  # new
                StructField("cant_venta_3meses", IntegerType(), True),  # new
                StructField("cant_producto_12meses", IntegerType(), True),  # new
                StructField("cant_producto_3meses", IntegerType(), True),  # new
                StructField("imp_bruto_me", DecimalType(38,12), True),  # new
                StructField("imp_bruto_mn", DecimalType(38,12), True),  # new
                StructField("imp_neto_me", DecimalType(38,12), True),  # new
                StructField("imp_neto_mn", DecimalType(38,12), True),  # new
                StructField("cant_caja_unitaria_pro", DecimalType(38,12), True),  # new
                StructField("cant_caja_fisica_pro", DecimalType(38,12), True),  # new
                StructField("cant_caja_unitaria_ven", DecimalType(38,12), True),  # new
                StructField("cant_caja_fisica_ven", DecimalType(38,12), True),  # new
            ]
        )

        self.dts_schemas["fact_kpi_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_producto", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                StructField("id_supervisor", StringType(), True),
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_modelo_atencion", StringType(), True),
                StructField("id_origen_pedido", StringType(), True),
                StructField("fecha_pedido", DateType(), True),
                StructField("cod_tipo_atencion", StringType(), True),
                StructField("id_visita", StringType(), True),
                StructField("id_visita_pedido", StringType(), True),
                StructField("id_visita_venta", StringType(), True),
                StructField("id_cliente_visita", StringType(), True),
                StructField("id_cliente_visita_pedido", StringType(), True),
                StructField("id_cliente_visita_venta", StringType(), True),
                StructField("cant_cajafisica_vta", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_vta", DecimalType(38,12), True),
                StructField("cant_cajafisica_pro", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_pro", DecimalType(38,12), True),
                StructField("imp_neto_vta_mn", DecimalType(38,12), True),
                StructField("imp_neto_vta_me", DecimalType(38,12), True),
                StructField("imp_bruto_vta_mn", DecimalType(38,12), True),
                StructField("imp_bruto_vta_me", DecimalType(38,12), True)
            ]
        )

        self.dts_schemas["fact_venta_cliente_historico"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_producto", StringType(), True),
                StructField("id_forma_pago", StringType(), True),
                StructField("id_lista_precio", StringType(), True),
                StructField("fecha_liquidacion", DateType(), True),
                StructField("desc_region", StringType(), True),
                StructField("desc_subregion", StringType(), True),
                StructField("desc_division", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("cant_cajafisica_vta", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_vta", DecimalType(38,12), True),
                StructField("cant_cajafisica_pro", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_pro", DecimalType(38,12), True),
                StructField("imp_neto_vta_mn", DecimalType(38,12), True),
                StructField("imp_neto_vta_me", DecimalType(38,12), True),
                StructField("imp_bruto_vta_mn", DecimalType(38,12), True),
                StructField("imp_bruto_vta_me", DecimalType(38,12), True),
                StructField("imp_dscto_mn", DecimalType(38,12), True),
                StructField("imp_dscto_me", DecimalType(38,12), True),
                StructField("imp_dscto_sinimpvta_mn", DecimalType(38,12), True),
                StructField("imp_dscto_sinimpvta_me", DecimalType(38,12), True),
                StructField("imp_cobrar_vta_mn", DecimalType(38,12), True),
                StructField("imp_cobrar_vta_me", DecimalType(38,12), True),
                StructField("imp_paquete_vta_mn", DecimalType(38,12), True),
                StructField("imp_paquete_vta_me", DecimalType(38,12), True),
                StructField("imp_sugerido_mn", DecimalType(38,12), True),
                StructField("imp_sugerido_me", DecimalType(38,12), True),
                StructField("imp_full_vta_mn", DecimalType(38,12), True),
                StructField("imp_full_vta_me", DecimalType(38,12), True),
                StructField("imp_valorizado_pro_mn", DecimalType(38,12), True),
                StructField("imp_valorizado_pro_me", DecimalType(38,12), True),
                StructField("imp_impuesto1_mn", DecimalType(38,12), True),
                StructField("imp_impuesto1_me", DecimalType(38,12), True),
                StructField("imp_impuesto2_mn", DecimalType(38,12), True),
                StructField("imp_impuesto2_me", DecimalType(38,12), True),
                StructField("imp_impuesto3_mn", DecimalType(38,12), True),
                StructField("imp_impuesto3_me", DecimalType(38,12), True),
                StructField("imp_impuesto4_mn", DecimalType(38,12), True),
                StructField("imp_impuesto4_me", DecimalType(38,12), True),
                StructField("imp_impuesto5_mn", DecimalType(38,12), True),
                StructField("imp_impuesto5_me", DecimalType(38,12), True),
                StructField("imp_impuesto6_mn", DecimalType(38,12), True),
                StructField("imp_impuesto6_me", DecimalType(38,12), True)
            ]
        )

        self.dts_schemas["fact_venta_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_producto", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                StructField("id_supervisor", StringType(), True),
                StructField("id_forma_pago", StringType(), True),
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_modelo_atencion", StringType(), True),
                StructField("id_lista_precio", StringType(), True),
                StructField("id_origen_pedido", StringType(), True),
                StructField("id_tipo_venta", StringType(), True),
                StructField("id_documento_venta", StringType(), True),
                StructField("id_documento_pedido", StringType(), True),
                StructField("fecha_emision", DateType(), True),
                StructField("fecha_liquidacion", DateType(), True),
                StructField("fecha_pedido", DateType(), True),
                StructField("nro_venta", StringType(), True),
                StructField("nro_pedido", StringType(), True),
                StructField("desc_region", StringType(), True),
                StructField("desc_subregion", StringType(), True),
                StructField("desc_division", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("cant_cajafisica_vta", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_vta", DecimalType(38,12), True),
                StructField("cant_cajafisica_pro", DecimalType(38,12), True),
                StructField("cant_cajaunitaria_pro", DecimalType(38,12), True),
                StructField("imp_neto_vta_mn", DecimalType(38,12), True),
                StructField("imp_neto_vta_me", DecimalType(38,12), True),
                StructField("imp_bruto_vta_mn", DecimalType(38,12), True),
                StructField("imp_bruto_vta_me", DecimalType(38,12), True),
                StructField("imp_dscto_mn", DecimalType(38,12), True),
                StructField("imp_dscto_me", DecimalType(38,12), True),
                StructField("imp_dscto_sinimpvta_mn", DecimalType(38,12), True),
                StructField("imp_dscto_sinimpvta_me", DecimalType(38,12), True),
                StructField("imp_cobrar_vta_mn", DecimalType(38,12), True),
                StructField("imp_cobrar_vta_me", DecimalType(38,12), True),
                StructField("imp_paquete_vta_mn", DecimalType(38,12), True),
                StructField("imp_paquete_vta_me", DecimalType(38,12), True),
                StructField("imp_sugerido_mn", DecimalType(38,12), True),
                StructField("imp_sugerido_me", DecimalType(38,12), True),
                StructField("imp_full_vta_mn", DecimalType(38,12), True),
                StructField("imp_full_vta_me", DecimalType(38,12), True),
                StructField("imp_valorizado_pro_mn", DecimalType(38,12), True),
                StructField("imp_valorizado_pro_me", DecimalType(38,12), True),
                StructField("imp_impuesto1_mn", DecimalType(38,12), True),
                StructField("imp_impuesto1_me", DecimalType(38,12), True),
                StructField("imp_impuesto2_mn", DecimalType(38,12), True),
                StructField("imp_impuesto2_me", DecimalType(38,12), True),
                StructField("imp_impuesto3_mn", DecimalType(38,12), True),
                StructField("imp_impuesto3_me", DecimalType(38,12), True),
                StructField("imp_impuesto4_mn", DecimalType(38,12), True),
                StructField("imp_impuesto4_me", DecimalType(38,12), True),
                StructField("imp_impuesto5_mn", DecimalType(38,12), True),
                StructField("imp_impuesto5_me", DecimalType(38,12), True),
                StructField("imp_impuesto6_mn", DecimalType(38,12), True),
                StructField("imp_impuesto6_me", DecimalType(38,12), True)
            ]
        )

        self.dts_schemas["fact_avance_dia_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_avance_dia", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_modelo_atencion", StringType(), True),
                StructField("cod_avance_dia", StringType(), True),
                StructField("cod_unidad", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("desc_modulo", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("desc_ruta", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("desc_zona", StringType(), True),
                StructField("fecha_avance_dia", DateType(), True),
                StructField("fecha_inicio", TimestampType(), True),
                StructField("fecha_fin", TimestampType(), True),
                StructField("coordx_inicio", StringType(), True),
                StructField("coordx_fin", StringType(), True),
                StructField("coordy_inicio", StringType(), True),
                StructField("coordy_fin", StringType(), True),
                StructField("distancia_recorrida", DoubleType(), True),
                StructField("cant_cuota_cambio", StringType(), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
                StructField("es_eliminado", IntegerType(), True),
                StructField("avance_cajas_unitarias__c", StringType(), True),
                StructField("avance_cajas__c", DoubleType(), True),
                StructField("avance_del_dia__c", DoubleType(), True),
                StructField("avance_del_mes__c", StringType(), True),
                StructField("avance_importe__c", DoubleType(), True),
                StructField("bateria__c", StringType(), True),
                StructField("cajas_totales_cliente_nuevo__c", DoubleType(), True),
                StructField("cajas_totales_extra_ruta__c", DoubleType(), True),
                StructField("cajas_totales_prospecto__c", DoubleType(), True),
                StructField("cajas_totales_vendedor__c", DoubleType(), True),
                StructField("cajas_totales__c", DoubleType(), True),
                StructField("categorias__c", StringType(), True),
                StructField("clientes_compra_0__c", DoubleType(), True),
                StructField("clientes_compra__c", DoubleType(), True),
                StructField("clientes_visitados__c", DoubleType(), True),
                StructField("codigo_unico_vendedor__c", StringType(), True),
                StructField("codigo_vendedor__c", StringType(), True),
                StructField("compania__c", StringType(), True),
                StructField("createdbyid", StringType(), True),
                StructField("createddate", TimestampType(), True),
                StructField("cuota_de_cambio__c", DoubleType(), True),
                StructField("cuota_de_ruta__c", StringType(), True),
                StructField("currencyisocode", StringType(), True),
                StructField("device_id__c", StringType(), True),
                StructField("diferencia_clientes_compra_total_pedidos__c", BooleanType(), True),
                StructField("drop_size__c", DoubleType(), True),
                StructField("efectividad__c", DoubleType(), True),
                StructField("enviar_a_call_center__c", BooleanType(), True),
                StructField("fecha_fin_dia__c", DateType(), True),
                StructField("fecha_hora_primer_pedido__c", TimestampType(), True),
                StructField("fecha_hora_primer_visita__c", TimestampType(), True),
                StructField("fecha_hora_ultima_sincronizacion__c", TimestampType(), True),
                StructField("fecha_hora_ultima_visita_c__c", TimestampType(), True),
                StructField("fecha_hora_ultimo_pedido__c", TimestampType(), True),
                StructField("fecha_inicio_dia__c", DateType(), True),
                StructField("fecha_vendedor__c", StringType(), True),
                StructField("fecha__c", TimestampType(), True),
                StructField("fin_de_dia__c", StringType(), True),
                StructField("fuerza_de_venta__c", StringType(), True),
                StructField("hora_fin_dia__c", StringType(), True),
                StructField("hora_inicio_dia__c", StringType(), True),
                StructField("id", StringType(), True),
                StructField("id_agente__c", StringType(), True),
                StructField("inicio_de_dia__c", StringType(), True),
                StructField("isdeleted", BooleanType(), True),
                StructField("kpi_cajas__c", StringType(), True),
                StructField("kpi_cobertura_simple__c", StringType(), True),
                StructField("kpi_importe__c", StringType(), True),
                StructField("lastactivitydate", TimestampType(), True),
                StructField("lastmodifiedbyid", StringType(), True),
                StructField("lastmodifieddate", TimestampType(), True),
                StructField("lastreferenceddate", TimestampType(), True),
                StructField("lastvieweddate", TimestampType(), True),
                StructField("latitud_fin__c", StringType(), True),
                StructField("latitud__c", StringType(), True),
                StructField("longitud_fin__c", StringType(), True),
                StructField("longitud__c", StringType(), True),
                StructField("marcas__c", StringType(), True),
                StructField("modelo_atencion__c", StringType(), True),
                StructField("modulo__c", StringType(), True),
                StructField("name", StringType(), True),
                StructField("necesidad_cu_diaria__c", DoubleType(), True),
                StructField("necesidad_diaria_importe__c", DoubleType(), True),
                StructField("necesidad_diaria__c", DoubleType(), True),
                StructField("nombre_region__c", StringType(), True),
                StructField("nombre_subregion__c", StringType(), True),
                StructField("nombre_vendedor__c", StringType(), True),
                StructField("numero__c", StringType(), True),
                StructField("ownerid", StringType(), True),
                StructField("pais__c", StringType(), True),
                StructField("portafolio__c", StringType(), True),
                StructField("region__c", StringType(), True),
                StructField("rutan__c", StringType(), True),
                StructField("ruta__c", StringType(), True),
                StructField("subregion__c", StringType(), True),
                StructField("sucursal__c", StringType(), True),
                StructField("systemmodstamp", StringType(), True),
                StructField("telefono_vendedor__c", StringType(), True),
                StructField("total_cajas_cliente_nuevo__c", DoubleType(), True),
                StructField("total_cajas_extra_ruta__c", DoubleType(), True),
                StructField("total_cajas_fisicas__c", DoubleType(), True),
                StructField("total_cajas_prospectos__c", DoubleType(), True),
                StructField("total_cajas_vendedor__c", DoubleType(), True),
                StructField("total_clientes_activos__c", DoubleType(), True),
                StructField("total_clientes_compra2__c", DoubleType(), True),
                StructField("total_clientes__c", DoubleType(), True),
                StructField("total_de_cajas__c", DoubleType(), True),
                StructField("total_de_caja_unidades__c", DoubleType(), True),
                StructField("total_importe_cliente_nuevo__c", DoubleType(), True),
                StructField("total_importe_extra_ruta__c", DoubleType(), True),
                StructField("total_importe_prospecto__c", DoubleType(), True),
                StructField("total_importe_vendedor__c", DoubleType(), True),
                StructField("total_importe__c", DoubleType(), True),
                StructField("total_no_pedidos__c", DoubleType(), True),
                StructField("total_pedidos_cliente_nuevo__c", DoubleType(), True),
                StructField("total_pedidos_extra_ruta__c", DoubleType(), True),
                StructField("total_pedidos_prospecto__c", DoubleType(), True),
                StructField("total_pedidos__c", DoubleType(), True),
                StructField("total_skus_cliente_nuevo__c", DoubleType(), True),
                StructField("total_skus_extra_ruta__c", DoubleType(), True),
                StructField("total_skus_prospecto__c", DoubleType(), True),
                StructField("total_skus__c", DoubleType(), True),
                StructField("total_unidades_cliente_nuevo__c", DoubleType(), True),
                StructField("total_unidades_extra_ruta__c", DoubleType(), True),
                StructField("total_unidades_prospecto__c", DoubleType(), True),
                StructField("total_unidades__c", DoubleType(), True),
                StructField("unidades_cambiadas__c", DoubleType(), True),
                StructField("vendedor_volante__c", StringType(), True),
                StructField("vendedor__c", StringType(), True),
                StructField("version_app__c", StringType(), True),
                StructField("version_del_app__c", StringType(), True),
                StructField("zonan__c", StringType(), True),
                StructField("zona__c", StringType(), True),
                StructField("cu_totales_vendedor__c", DoubleType(), True),
                StructField("efectividad_preventa_ecommerce__c", DoubleType(), True),
                StructField("efectividad_visita_ecommerce__c", DoubleType(), True),
                StructField("clientes_pedidos_ecommerce__c", DoubleType(), True),
                StructField("efectividad_contacto__c", DoubleType(), True)
            ]
        )

        self.dts_schemas["fact_pedido_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_pedido", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_visita", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_modelo_atencion", StringType(), True),
                StructField("id_origen_pedido", StringType(), True),
                StructField("id_tipo_pedido", StringType(), True),
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                StructField("id_supervisor", StringType(), True),
                StructField("id_jefe_venta", StringType(), True),
                StructField("id_lista_precio", StringType(), True),
                StructField("id_forma_pago", StringType(), True),
                StructField("desc_region", StringType(), True),
                StructField("desc_subregion", StringType(), True),
                StructField("desc_division", StringType(), True),
                StructField("desc_estado", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("cod_pedido_salesforce", StringType(), True),
                StructField("cod_pedido_sugerido", StringType(), True),
                StructField("es_pedido_sugerido", StringType(), True),
                StructField("es_prospecto", IntegerType(), True),
                StructField("es_extramodulo", IntegerType(), True),
                StructField("es_eliminado", IntegerType(), True),
                StructField("fecha_pedido", DateType(), True),
                StructField("fecha_entrega", DateType(), True),
                StructField("fecha_visita", DateType(), True),
                StructField("nro_pedido", StringType(), True),
                StructField("cod_motivo_no_pedido", StringType(), True),
                StructField("fecha_no_pedido", TimestampType(), True),
                StructField("cant_cajafisica_ped", DoubleType(), True),
                StructField("cant_cajavolumen_ped", DoubleType(), True),
                StructField("cant_cajafisica_ped_pro", DoubleType(), True),
                StructField("cant_cajavolumen_ped_pro", DoubleType(), True),
                StructField("cant_cajafisica_asignado_ped", DoubleType(), True),
                StructField("cant_cajavolumen_asignado_ped", DoubleType(), True),
                StructField("cant_cajafisica_asignado_ped_pro", DoubleType(), True),
                StructField("cant_cajavolumen_asignado_ped_pro", DoubleType(), True),
                StructField("imp_bruto_ped_mn", DoubleType(), True),
                StructField("imp_bruto_ped_me", DoubleType(), True),
                StructField("imp_dscto_ped_mn", DoubleType(), True),
                StructField("imp_dscto_ped_me", DoubleType(), True),
                StructField("imp_neto_ped_mn", DoubleType(), True),
                StructField("imp_neto_ped_me", DoubleType(), True),
                StructField("fuente", StringType(), True)
            ]
        )

        self.dts_schemas["fact_visita_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_avance_dia", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_modelo_atencion", StringType(), True),
                StructField("cod_avance_dia", StringType(), True),
                StructField("cod_unidad", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("desc_modulo", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("desc_ruta", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("desc_zona", StringType(), True),
                StructField("fecha_avance_dia", DateType(), True),
                StructField("fecha_inicio_avance", TimestampType(), True),
                StructField("fecha_fin_avance", TimestampType(), True),
                StructField("coordx_inicio", StringType(), True),
                StructField("coordx_fin", StringType(), True),
                StructField("coordy_inicio", StringType(), True),
                StructField("coordy_fin", StringType(), True),
                StructField("distancia_recorrida", DoubleType(), True),
                StructField("cant_cuota_cambio", StringType(), True),
                StructField("es_eliminado", IntegerType(), True),
                StructField("id_visita", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_visita_anterior", StringType(), True),
                StructField("cod_visita", StringType(), True),
                StructField("fecha_visita", DateType(), True),
                StructField("fecha_inicio_visita", TimestampType(), True),
                StructField("fecha_fin_visita", TimestampType(), True),
                StructField("tiempo_visita_transcurrido", StringType(), True),
                StructField("secuencia", StringType(), True),
                StructField("es_activo", IntegerType(), True),
                StructField("es_programado", IntegerType(), True),
                StructField("es_pedido_sugerido", IntegerType(), True),
                StructField("es_visita_auto", IntegerType(), True),
                StructField("desc_motivo_no_pedido", StringType(), True),
                StructField("coordx", StringType(), True),
                StructField("coordy", StringType(), True),
                StructField("distancia_fin", StringType(), True),
                StructField("tiempo_visita", StringType(), True),
                StructField("fecha_check_in", StringType(), True),
                StructField("fecha_check_out", StringType(), True),
                StructField("es_check_out_automatico", IntegerType(), True),
                StructField("es_pedido_levantado", IntegerType(), True),
                StructField("cant_total_cajas", DoubleType(), True),
                StructField("cant_total_cajas_fisicas", DoubleType(), True),
                StructField("imp_total", DoubleType(), True),
                StructField("cant_total_litros", DoubleType(), True),
                StructField("cant_total_pedidos", DoubleType(), True),
                StructField("cant_total_skus", DoubleType(), True),
                StructField("cant_total_unidades", DoubleType(), True),
                StructField("cant_total_unidades_cambio", DoubleType(), True)
            ]
        )

        self.dts_schemas["fact_venta_manejantes"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_cliente", StringType(), True),
                StructField("id_producto", StringType(), True),
                StructField("imp_neto_vta_mn", DoubleType(), True),
                StructField("imp_neto_vta_me", DoubleType(), True),
                StructField("imp_bruto_vta_mn", DoubleType(), True),
                StructField("imp_bruto_vta_me", DoubleType(), True),
                StructField("cant_cajafisica_vta", DoubleType(), True),
                StructField("cant_cajaunitaria_vta", DoubleType(), True),
                StructField("fecha_liquidacion", DateType(), True),
                StructField("m0", StringType(), True),
                StructField("m1", StringType(), True),
                StructField("m2", StringType(), True),
                StructField("m3", StringType(), True),
                StructField("m4", StringType(), True),
                StructField("m5", StringType(), True),
                StructField("m6", StringType(), True),
                StructField("m7", StringType(), True),
                StructField("m8", StringType(), True),
                StructField("m9", StringType(), True),
                StructField("m10", StringType(), True),
                StructField("m11", StringType(), True),
                StructField("m12", StringType(), True),
            ]
        )

        self.dts_schemas["fact_reparto_detalle"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_reparto", StringType(), True),
                StructField("id_pedido", StringType(), True),
                StructField("id_producto", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_transportista", StringType(), True),
                StructField("id_chofer", StringType(), True),
                StructField("id_medio_transporte", StringType(), True),
                StructField("id_cliente", StringType(), True),
                # StructField("id_modelo_atencion", StringType(), True), # no va
                StructField("id_origen_pedido", StringType(), True),
                StructField("id_tipo_pedido", StringType(), True),
                StructField("id_fuerza_venta", StringType(), True),
                StructField("id_vendedor", StringType(), True),
                # StructField("id_supervisor", StringType(), True), # no va
                # StructField("id_jefe_venta", StringType(), True), # no va
                StructField("id_lista_precio", StringType(), True),
                StructField("id_forma_pago", StringType(), True),
                StructField("desc_region", StringType(), True),
                StructField("desc_subregion", StringType(), True),
                StructField("desc_division", StringType(), True),
                StructField("cod_zona", StringType(), True),
                StructField("cod_ruta", StringType(), True),
                StructField("cod_modulo", StringType(), True),
                StructField("cod_pedido_salesforce", StringType(), True),
                StructField("fecha_pedido", DateType(), True),
                StructField("fecha_entrega", DateType(), True),
                StructField("fecha_orden_carga", DateType(), True),
                StructField("fecha_movimiento_inventario", DateType(), True),
                StructField("fecha_venta", DateType(), True),
                StructField("fecha_almacen", DateType(), True),
                StructField("nro_pedido", StringType(), True),
                StructField("estado_guia", StringType(), True),
                StructField("cant_cajafisica_ped", DecimalType(38,12), True),
                StructField("cant_cajavolumen_ped", DecimalType(38,12), True),
                StructField("cant_cajafisica_ped_pro", DecimalType(38,12), True),
                StructField("cant_cajavolumen_ped_pro", DecimalType(38,12), True),
                StructField("cant_cajafisica_asignado_ped", DecimalType(38,12), True),
                StructField("cant_cajavolumen_asignado_ped", DecimalType(38,12), True),
                StructField("cant_cajafisica_asignado_ped_pro", DecimalType(38,12), True),
                StructField("cant_cajavolumen_asignado_ped_pro", DecimalType(38,12), True),
                StructField("cant_cajafisica_desp", DecimalType(38,12), True),
                StructField("cant_cajavolumen_desp", DecimalType(38,12), True),
                StructField("cant_cajafisica_desp_pro", DecimalType(38,12), True),
                StructField("cant_cajavolumen_desp_pro", DecimalType(38,12), True),
                StructField("cant_cajafisica_ven", DecimalType(38,12), True),
                StructField("cant_cajavolumen_ven", DecimalType(38,12), True),
                StructField("cant_cajafisica_pro", DecimalType(38,12), True),
                StructField("cant_cajavolumen_pro", DecimalType(38,12), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
            ]
        )

    def get_schema(self, table_name):
        if table_name in self.dts_schemas:
            return self.dts_schemas[table_name]
        else:
            self.logger(f"{table_name} schema not found")
            return None

class SchemaDominioCadena:
    def __init__(self, logger):
        self.logger = logger
        self.dts_schemas = {}

        # =========================================================================
        # t_orden_compra_ingreso
        # Ajustes:
        #  - es_eliminado, tiene_factura => integer vs char => IntegerType() # se cambió
        #  - cant_facturada, cant_ingresada => numeric vs double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_orden_compra_ingreso"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_orden_compra", StringType(), True),
            StructField("id_orden_ingreso", StringType(), True),
            StructField("id_movimiento_ingreso", StringType(), True),
            StructField("id_compania_compra", StringType(), True),
            StructField("id_sucursal_compra", StringType(), True),
            StructField("id_compania_ingreso", StringType(), True),
            StructField("id_sucursal_ingreso", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("fecha_ingreso", DateType(), True),
            StructField("fecha_entrega", DateType(), True),
            StructField("nro_orden_compra", StringType(), True),
            StructField("cod_tipo_documento_compra", StringType(), True),
            StructField("cod_tipo_documento_ingreso", StringType(), True),
            StructField("cod_tipo_documento_exp", StringType(), True),
            StructField("nro_secuencia_compra", StringType(), True),
            StructField("nro_secuencia_ingreso", StringType(), True),
            StructField("nro_nota_ingreso", StringType(), True),
            StructField("tiene_factura", IntegerType(), True),          # se cambió
            StructField("nro_expediente", StringType(), True),
            StructField("cod_doc_referencia", StringType(), True),
            StructField("nro_doc_referencia", StringType(), True),
            StructField("desc_estado", StringType(), True),
            StructField("cod_unidad_ingreso", StringType(), True),
            StructField("cant_ingresada", DecimalType(38,12), True),    # se cambió
            StructField("cant_facturada", DecimalType(38,12), True),    # se cambió
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)            # se cambió
        ])
        # =========================================================================
        # t_orden_compra_cabecera
        # Ajustes:
        #  - es_eliminado, es_anulado, tiene_factura, tiene_impuesto_incluido,
        #    es_aprobado, es_atendido: Redshift=integer vs Athena=character => IntegerType() # se cambió
        #  - tipo_cambio_mn, tipo_cambio_me, imp_neto_mo, imp_neto_mn, imp_neto_me:
        #    Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_orden_compra_cabecera"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_orden_compra", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_proveedor", StringType(), True),
            StructField("id_almacen", StringType(), True),
            StructField("id_empleado_aprobado", StringType(), True),
            StructField("id_empleado_preparado", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("id_forma_pago", StringType(), True),
            StructField("fecha_emision", DateType(), True),
            StructField("fecha_atencion", DateType(), True),
            StructField("fecha_aprobacion", DateType(), True),
            StructField("fecha_entrega", DateType(), True),
            StructField("cod_tipo_documento", StringType(), True),
            StructField("nro_orden_compra", StringType(), True),
            StructField("desc_tipo_orden", StringType(), True),
            StructField("es_atendido", IntegerType(), True),              # se cambió
            StructField("es_aprobado", IntegerType(), True),              # se cambió
            StructField("tiene_impuesto_incluido", IntegerType(), True),  # se cambió
            StructField("tiene_factura", IntegerType(), True),            # se cambió
            StructField("es_anulado", IntegerType(), True),               # se cambió
            StructField("desc_estado_orden_compra", StringType(), True),
            StructField("imp_neto_mo", DecimalType(38, 12), True),        # se cambió
            StructField("imp_neto_mn", DecimalType(38, 12), True),        # se cambió
            StructField("imp_neto_me", DecimalType(38, 12), True),        # se cambió
            StructField("cod_moneda_mo", StringType(), True),
            StructField("cod_moneda_mn", StringType(), True),
            StructField("tipo_cambio_me", DecimalType(38, 12), True),     # se cambió
            StructField("tipo_cambio_mn", DecimalType(38, 12), True),     # se cambió
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)             # se cambió
        ])
        # =========================================================================
        # t_orden_compra_detalle
        # Ajustes:
        #  - es_eliminado, es_atendido: Redshift=integer vs Athena=character => IntegerType() # se cambió
        #  - Muchas columnas numeric vs double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_orden_compra_detalle"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_orden_compra", StringType(), True),
            StructField("id_orden_ingreso", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("fecha_emision", DateType(), True),
            StructField("desc_tipo_detalle", StringType(), True),
            StructField("cod_tipo_documento", StringType(), True),
            StructField("nro_orden_compra", StringType(), True),
            StructField("nro_secuencia", StringType(), True),
            StructField("es_atendido", IntegerType(), True),             # se cambió
            StructField("cod_unidad_compra", StringType(), True),
            StructField("precio_compra_mo", DecimalType(38,12), True),   # se cambió
            StructField("precio_compra_me", DecimalType(38,12), True),   # se cambió
            StructField("precio_compra_mn", DecimalType(38,12), True),   # se cambió
            StructField("cant_comprada", DecimalType(38,12), True),      # se cambió
            StructField("cant_antendida", DecimalType(38,12), True),     # se cambió
            StructField("cant_facturada", DecimalType(38,12), True),     # se cambió
            StructField("cant_cancelada", DecimalType(38,12), True),     # se cambió
            StructField("precio_std_mn", DecimalType(38,12), True),      # se cambió
            StructField("precio_std_me", DecimalType(38,12), True),      # se cambió
            StructField("imp_compra_mo", DecimalType(38,12), True),      # se cambió
            StructField("imp_compra_mn", DecimalType(38,12), True),      # se cambió
            StructField("imp_compra_me", DecimalType(38,12), True),      # se cambió
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)             # se cambió
        ])

        # =========================================================================
        # t_orden_compra_cronograma_entrega
        # Ajustes:
        #  - es_eliminado: Redshift=integer vs Athena=character => IntegerType() # se cambió
        #  - cant_atendida, cant_perdida: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_orden_compra_cronograma_entrega"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("cod_transaccion", StringType(), True),
            StructField("nro_documento", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("id_proveedor", StringType(), True),
            StructField("nro_secuencia", StringType(), True),
            StructField("desc_tipo_detalle", StringType(), True),
            StructField("cant_perdida", DecimalType(38, 12), True),   # se cambió
            StructField("cant_atendida", DecimalType(38, 12), True),  # se cambió
            StructField("fecha_inicio", DateType(), True),
            StructField("fecha_final", DateType(), True),
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)          # se cambió
        ])
        self.dts_schemas["m_categoria_compra"] = StructType(
            [
                StructField("id_categoria_compra", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_categoria", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("cod_categoria", StringType(), True),
                StructField("desc_categoria", StringType(), True),
                StructField("cod_subcategoria", StringType(), True),
                StructField("desc_subcategoria", StringType(), True),
                StructField("cod_subcategoria2", StringType(), True),
                StructField("desc_subcategoria2", StringType(), True),
                StructField("cod_unidad_global", StringType(), True),
            ]
        )
        self.dts_schemas["m_proveedor"] = StructType(
            [
                StructField("id_proveedor", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("cod_proveedor", StringType(), True),
                StructField("nomb_proveedor", StringType(), True),
                StructField("ruc_proveedor", StringType(), True),
                StructField("desc_estado", StringType(), True)
            ]
        )
        # =========================================================================
        # m_unidad_medida_equivalente
        # Ajustes:
        #  - cant_operacion: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["m_unidad_medida_equivalente"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("cod_unidad_medida_desde", StringType(), True),
            StructField("cod_unidad_medida_hasta", StringType(), True),
            StructField("cod_operador", StringType(), True),
            StructField("cant_operacion", DecimalType(38, 12), True)   # se cambió
        ])
        # =========================================================================
        # t_compra_rendimiento
        # Ajustes:
        #  - cant_consumida, cant_producida, precio_std_me: Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_compra_rendimiento"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("fecha_rendimiento", DateType(), True),
            StructField("cant_consumida", DecimalType(38, 12), True),   # se cambió
            StructField("cant_producida", DecimalType(38, 12), True),   # se cambió
            StructField("precio_std_me", DecimalType(38, 12), True)     # se cambió
        ])
        # =========================================================================
        # t_hoja_costos_cabecera
        # Ajustes:
        #  - es_eliminado: Redshift=integer vs Athena=character => IntegerType() # se cambió
        #  - cant_girada, precio_cpm_mn, precio_cpm_me, precio_std_mn, precio_std_me:
        #       Redshift=numeric vs Athena=double => DecimalType(38,12) # se cambió
        # =========================================================================
        self.dts_schemas["t_hoja_costos_cabecera"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("nro_operacion", StringType(), True),
            StructField("fecha_liquidacion", DateType(), True),
            StructField("cod_unidad_manejo", StringType(), True),
            StructField("cod_unidad_medida", StringType(), True),
            StructField("cant_girada", DecimalType(38, 12), True),      # se cambió
            StructField("precio_cpm_mn", DecimalType(38, 12), True),    # se cambió
            StructField("precio_cpm_me", DecimalType(38, 12), True),    # se cambió
            StructField("precio_std_mn", DecimalType(38, 12), True),    # se cambió
            StructField("precio_std_me", DecimalType(38, 12), True),    # se cambió
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)            # se cambió
        ])
        # =========================================================================
        # t_movimiento_inventario
        # Ajustes:
        #  - Columna faltante: tiene_transito => Redshift=integer => IntegerType() # faltaba
        #  - es_eliminado: Redshift=integer vs Athena=character => IntegerType() # se cambió
        # =========================================================================
        self.dts_schemas["t_movimiento_inventario"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_movimiento_almacen", StringType(), True),
            StructField("id_movimiento_ingreso", StringType(), True),
            StructField("id_compania_origen", StringType(), True),
            StructField("id_sucursal_origen", StringType(), True),
            StructField("id_almacen_origen", StringType(), True),
            StructField("id_compania_destino", StringType(), True),
            StructField("id_sucursal_destino", StringType(), True),
            StructField("id_almacen_destino", StringType(), True),
            StructField("id_compania_referencia", StringType(), True),
            StructField("id_sucursal_referencia", StringType(), True),
            StructField("id_almacen_referencia", StringType(), True),
            StructField("id_transportista", StringType(), True),
            StructField("id_medio_transporte", StringType(), True),
            StructField("id_vendedor", StringType(), True),
            StructField("id_persona", StringType(), True),
            StructField("id_tipo_procedimiento", StringType(), True),
            StructField("fecha_emision", DateType(), True),
            StructField("cod_procedimiento", StringType(), True),
            StructField("fecha_liquidacion", DateType(), True),
            StructField("fecha_almacen", DateType(), True),
            StructField("nro_documento_almacen", StringType(), True),
            StructField("nro_documento_movimiento", StringType(), True),
            StructField("cod_estado_comprobante", StringType(), True),
            StructField("nro_serie_almacen", StringType(), True),
            StructField("nro_comprobante_pre", StringType(), True),
            StructField("cod_documento_liquidacion", StringType(), True),
            StructField("nro_documento_liquidacion", StringType(), True),
            StructField("cod_documento_transaccion", StringType(), True),
            StructField("cod_documento_transaccion_ref1", StringType(), True),
            StructField("nro_documento_almacen_ref1", StringType(), True),
            StructField("cod_documento_transaccion_ref2", StringType(), True),
            StructField("nro_documento_almacen_ref2", StringType(), True),
            StructField("desc_estado_transito", StringType(), True),
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True),  # se cambió
            StructField("tiene_transito", IntegerType(), True) # faltaba
        ])
        # =========================================================================
        # t_movimiento_inventario_detalle
        # Ajustes más comunes: es_eliminado integer vs char => IntegerType() (si aplica).
        # En los logs hay menciones de columnas "faltantes" y numeric vs double,
        # pero tu script ya tiene la mayoría. Ajustaremos numeric->DecimalType(38,12).
        # =========================================================================
        self.dts_schemas["t_movimiento_inventario_detalle"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_almacen", StringType(), True),
            StructField("id_articulo", StringType(), True),
            StructField("id_movimiento_almacen", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("fecha_almacen", DateType(), True),
            StructField("nro_documento_movimiento", StringType(), True),
            StructField("nro_linea_comprobante", StringType(), True),
            StructField("cod_documento_transaccion", StringType(), True),
            StructField("nro_documento_almacen", StringType(), True),
            StructField("cod_documento_transaccion_referencia", StringType(), True),
            StructField("nro_documento_almacen_referencia", StringType(), True),
            StructField("cod_procedimiento", StringType(), True),
            StructField("cod_operacion_kardex", StringType(), True),
            StructField("cod_estado_comprobante", StringType(), True),
            StructField("cod_motivo", StringType(), True),
            StructField("cod_unidad_almacen", StringType(), True),
            StructField("nro_secuencia_origen", StringType(), True),
            StructField("cant_cajafisica", DecimalType(38,12), True),                     # se cambió
            StructField("cant_cajafisica_total", DecimalType(38,12), True),              # se cambió
            StructField("cant_unidades", DecimalType(38,12), True),                      # se cambió
            StructField("cant_unidades_total", DecimalType(38,12), True),                # se cambió
            StructField("cant_cajafisica_ingresada", DecimalType(38,12), True),          # se cambió
            StructField("cant_cajafisica_ingresada_total", DecimalType(38,12), True),    # se cambió
            StructField("cant_cajafisica_salida", DecimalType(38,12), True),             # se cambió
            StructField("cant_cajafisica_salida_total", DecimalType(38,12), True),       # se cambió
            StructField("cant_unidades_ingresada", DecimalType(38,12), True),            # se cambió
            StructField("cant_unidades_salida", DecimalType(38,12), True),               # se cambió
            StructField("cant_unidades_total_ingresada", DecimalType(38,12), True),      # se cambió
            StructField("cant_unidades_total_salida", DecimalType(38,12), True),         # se cambió
            StructField("imp_unitario", DecimalType(38,12), True),                       # se cambió
            StructField("imp_total", DecimalType(38,12), True),                          # se cambió
            StructField("imp_total_ingreso", DecimalType(38,12), True),                  # se cambió
            StructField("imp_total_salida", DecimalType(38,12), True),                   # se cambió
            StructField("imp_valorizado_ingreso", DecimalType(38,12), True),             # se cambió
            StructField("imp_valorizado_salida", DecimalType(38,12), True),              # se cambió
            StructField("cant_unidades_transito", DecimalType(38,12), True),             # se cambió
            StructField("imp_total_transito", DecimalType(38,12), True),                 # se cambió
            StructField("precio_unitario_mn", DecimalType(38,12), True),                 # se cambió
            StructField("precio_unitario_me", DecimalType(38,12), True),                 # se cambió
            StructField("imp_valorizado_mn", DecimalType(38,12), True),                  # se cambió
            StructField("imp_valorizado_me", DecimalType(38,12), True),                  # se cambió
            StructField("imp_saldo_inicial", DecimalType(38,12), True),                  # se cambió
            StructField("imp_saldo_final", DecimalType(38,12), True),                    # se cambió
            StructField("usuario_creacion", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("usuario_modificacion", StringType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            StructField("es_eliminado", IntegerType(), True)

        ])
        self.dts_schemas["m_almacen"] = StructType(
            [
                StructField("id_almacen", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("cod_almacen", StringType(), True),
                StructField("desc_almacen", StringType(), True),
                StructField("desc_tipo_almacen", StringType(), True),
            ]
        )
        self.dts_schemas["m_linea_almacen"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_almacen", StringType(), True),
                StructField("id_linea_almacen", StringType(), True),
                StructField("cod_linea", StringType(), True),
                StructField("desc_linea_almacen", StringType(), True),
                StructField("cod_grupo_linea", StringType(), True),
            ]
        )
        self.dts_schemas["t_saldos_iniciales"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_almacen", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("fecha_inventario", DateType(), True),
                StructField("cant_cajafisica_inicial", DecimalType(38, 12), True),
                StructField("cant_unidades_inicial", DecimalType(38, 12), True),
                StructField("estado", StringType(), True),
                StructField("precio_unitario_mn", DecimalType(38, 12), True),
                StructField("precio_unitario_me", DecimalType(38, 12), True),
                StructField("imp_valorizado_mn", DecimalType(38, 12), True),
                StructField("imp_valorizado_me", DecimalType(38, 12), True),
                StructField("imp_saldo_inicial", DecimalType(38, 12), True),
                StructField("imp_valorizado_ingreso", DecimalType(38, 12), True),
                StructField("imp_valorizado_salida", DecimalType(38, 12), True),
                StructField("imp_saldo_final", DecimalType(38, 12), True),
                StructField("usuario_creacion", StringType(), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("usuario_modificacion", StringType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
                StructField("es_eliminado", IntegerType(), True)             
            ]
        )
        self.dts_schemas["m_equipo_insumo"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_equipo_insumo", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_familia_equipo", StringType(), True),
                StructField("cod_equipo_insumo", StringType(), True),
                StructField("desc_equipo_insumo", StringType(), True),
                StructField("horas_por_turno", StringType(), True),
                StructField("estado", StringType(), True),
            ]
        )
        self.dts_schemas["m_familia_equipo"] = StructType(
            [
                StructField("id_familia_equipo", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("cod_familia_equipo", StringType(), True),
                StructField("cod_area", StringType(), True),
                StructField("desc_familia_equipo", StringType(), True),
                StructField("nivel_costo", DecimalType(38,12), True),
                StructField("estado", StringType(), True),
            ]
        )
        self.dts_schemas["m_formula_fabricacion"] = StructType(
            [
                StructField("id_formula_fabricacion", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("id_material", StringType(), True),
                StructField("cod_material", StringType(), True),
                StructField("porcentaje", DecimalType(38, 12), True),
                StructField("factor_conversion", DecimalType(38, 12), True),
                StructField("cant_fabricacion", DecimalType(38, 12), True),
                StructField("stock_disponible", DecimalType(38, 12), True),
                StructField("tipo_distribucion", StringType(), True)
            ]
        )
        self.dts_schemas["m_turno"] = StructType(
            [
                StructField("id_turno", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("cod_turno", StringType(), True),
                StructField("desc_turno", StringType(), True),
            ]
        )
        self.dts_schemas["t_orden_produccion_material"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_orden_produccion", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("nro_operacion", StringType(), True),
                StructField("cant_unidades_teorica", DecimalType(38, 12), True),
                StructField("cant_unidades_entregada", DecimalType(38, 12), True),
                StructField("cant_unidades_teorica_fabricada", DecimalType(38, 12), True),
                StructField("factor_conversion", DecimalType(38, 12), True),
                StructField("usuario_creacion", StringType(), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("usuario_modificacion", StringType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
                StructField("es_eliminado", IntegerType(), True)
            ]
        )
        self.dts_schemas["t_orden_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_orden_produccion", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_turno", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("id_familia_equipo", StringType(), True),
                StructField("id_almacen_origen", StringType(), True),
                StructField("nro_operacion", StringType(), True),
                StructField("cod_avail", StringType(), True),
                StructField("cod_linea_equipo", StringType(), True),
                StructField("cod_correlativo", StringType(), True),
                StructField("nro_lote", StringType(), True),
                StructField("desc_linea_fabricacion", StringType(), True),
                StructField("cant_unidades_por_minuto", DecimalType(38, 12), True),
                StructField("cant_unidades_teorica", DecimalType(38, 12), True),
                StructField("cant_unidades_girada", DecimalType(38, 12), True),
                StructField("cant_cajafisica_girada", DecimalType(38, 12), True),
                StructField("cant_unidades_fabricada", DecimalType(38, 12), True),
                StructField("cant_cajafisica_fabricada", DecimalType(38, 12), True),
                StructField("cant_cajafisica_plan", DecimalType(38, 12), True),
                StructField("cant_volumen_fabricado", DecimalType(38, 12), True),
                StructField("cant_cajavolumen_girada", DecimalType(38, 12), True),
                StructField("cant_velocidad_volumen", DecimalType(38, 12), True),
                StructField("cant_jornada_laboral", DecimalType(38, 12), True),
                StructField("cant_paradas_por_linea", DecimalType(38, 12), True),
                StructField("cant_paradas_ajena_linea", DecimalType(38, 12), True),
                StructField("cant_tiempo_ideal", DecimalType(38, 12), True),
                StructField("cant_velocidad", DecimalType(38, 12), True),
                StructField("cant_velocidad_hora", DecimalType(38, 12), True),
                StructField("total_tiempo_bruto", DecimalType(38, 12), True),
                StructField("total_tiempo_ideal", DecimalType(38, 12), True),
                StructField("fecha_giro", DateType(), True),
                StructField("fecha_inicio", DateType(), True),
                StructField("fecha_fin", DateType(), True),
                StructField("usuario_creacion", StringType(), True),
                StructField("fecha_creacion", TimestampType(), True),
                StructField("usuario_modificacion", StringType(), True),
                StructField("fecha_modificacion", TimestampType(), True),
                StructField("es_eliminado", IntegerType(), True)
            ]
        )
        self.dts_schemas["m_motivo_parada_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_motivo_parada_produccion", StringType(), True),
                StructField("cod_parada", StringType(), True),
                StructField("desc_tipo_envio", StringType(), True),
                StructField("cod_correlativo", StringType(), True),
                StructField("desc_motivo", StringType(), True),
                StructField("desc_motivo_detalle", StringType(), True),
                StructField("desc_clasificacion", StringType(), True),
            ]
        )
        self.dts_schemas["m_linea_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_linea_produccion", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_familia_equipo", StringType(), True),
                StructField("cod_linea_produccion", StringType(), True),
                StructField("desc_linea_produccion", StringType(), True),
                StructField("estado", StringType(), True),
            ]
        )
        self.dts_schemas["t_parada_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_parada_produccion", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_orden_produccion", StringType(), True),
                StructField("id_motivo_parada_produccion", StringType(), True),
                StructField("nro_operacion", StringType(), True),
                StructField("fecha_parada_produccion", DateType(), True),
                StructField("cant_frecuencia", DoubleType(), True),
                StructField("total_tiempo_minimo", DoubleType(), True),
                StructField("es_eliminado", StringType(), True),
            ]
        )
        self.dts_schemas["m_medio_transporte"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_medio_transporte", StringType(), True),
                StructField("cod_medio_transporte", StringType(), True),
                StructField("cod_tipo_medio_transporte", StringType(), True),
                StructField("desc_tipo_medio_transporte", StringType(), True),
                StructField("desc_marca_medio_transporte", StringType(), True),
                StructField("cod_tipo_capacidad", StringType(), True),
                StructField("cant_peso_maximo", IntegerType(), True),
                StructField("cant_tarimas", StringType(), True),
                StructField("fecha_creacion", DateType(), True),
                StructField("fecha_modificacion", DateType(), True),
            ]
        )
        self.dts_schemas["m_transportista"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                # StructField("id_compania", StringType(), True),
                StructField("id_transportista", StringType(), True),
                StructField("cod_transportista", StringType(), True),
                StructField("nomb_transportista", StringType(), True),
                StructField("cod_tipo_transportista", StringType(), True),
                StructField("desc_tipo_transportista", StringType(), True),
                StructField("ruc_transportista", StringType(), True),
                StructField("fecha_creacion", StringType(), True),
                StructField("fecha_modificacion", StringType(), True),
            ]
        )
        self.dts_schemas["t_pedido_detalle_cumplimiento"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_reparto", StringType(), True),
            StructField("id_pedido", StringType(), True),
            StructField("id_producto", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("fecha_venta", DateType(), True),
            StructField("cant_cajafisica_ped", DecimalType(38,12), True),
            StructField("cant_cajavolumen_ped", DecimalType(38,12), True),
            StructField("cant_cajafisica_ped_pro", DecimalType(38,12), True),
            StructField("cant_cajavolumen_ped_pro", DecimalType(38,12), True),
            StructField("cant_cajafisica_asignado_ped", DecimalType(38,12), True),
            StructField("cant_cajavolumen_asignado_ped", DecimalType(38,12), True),
            StructField("cant_cajafisica_asignado_ped_pro", DecimalType(38,12), True),
            StructField("cant_cajavolumen_asignado_ped_pro", DecimalType(38,12), True),
            StructField("cant_cajafisica_desp", DecimalType(38,12), True),
            StructField("cant_cajavolumen_desp", DecimalType(38,12), True),
            StructField("cant_cajafisica_desp_pro", DecimalType(38,12), True),
            StructField("cant_cajavolumen_desp_pro", DecimalType(38,12), True),
            StructField("cant_caja_fisica_ven", DecimalType(38,12), True),
            StructField("cant_caja_volumen_ven", DecimalType(38,12), True),
            StructField("cant_caja_fisica_pro", DecimalType(38,12), True),
            StructField("cant_caja_volumen_pro", DecimalType(38,12), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True),
        ])
        self.dts_schemas["t_reparto"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_reparto", StringType(), True),
            StructField("id_transportista", StringType(), True),
            StructField("id_medio_transporte", StringType(), True),
            StructField("id_chofer", StringType(), True),
            # StructField("estado_reparto", StringType(), True),
            StructField("fecha_orden_carga", DateType(), True),
            StructField("fecha_reparto", DateType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True),
            # StructField("es_eliminado", IntegerType(), True),
            StructField("estado_guia", StringType(), True),
        ])

        self.dts_schemas["m_periodo_contable"] = StructType([
            StructField("id_periodo_contable", StringType(), True),
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_periodo", StringType(), True),
            StructField("cierre_mes", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_centro_costo"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("id_centro_costo_corp", StringType(), True),
            StructField("id_area", StringType(), True),
            StructField("id_gerencia", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_centro_costo", StringType(), True),
            StructField("desc_centro_costo", StringType(), True),
            StructField("cod_centro_costo_corp", StringType(), True),
            StructField("desc_centro_costo_corp", StringType(), True),
            StructField("cod_area", StringType(), True),
            StructField("cod_gerencia", StringType(), True),
            StructField("cod_tipo", StringType(), True),
            StructField("cod_tipo_almacen", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_centro_costo_corporativo"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_centro_costo_corp", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_centro_costo_corporativo", StringType(), True),
            StructField("desc_centro_costo_corporativo", StringType(), True),
            StructField("cod_area", StringType(), True),
            StructField("cod_gerencia", StringType(), True),
            StructField("ind_trabcur", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_area"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_area", StringType(), True),
            StructField("id_gerencia", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_area", StringType(), True),
            StructField("cod_gerencia", StringType(), True),
            StructField("cod_sucursal", StringType(), True),
            StructField("desc_area", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_gerencia"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_gerencia", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_gerencia", StringType(), True),
            StructField("cod_sucursal", StringType(), True),
            StructField("desc_gerencia", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_plan_cuentas"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_ejercicio", StringType(), True),
            StructField("id_cuenta_contable", StringType(), True),
            StructField("id_cuenta_contable_corp", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_cuenta_contable", StringType(), True),
            StructField("desc_cuenta_contable", StringType(), True),
            StructField("cod_tipo_cuenta", StringType(), True),
            StructField("cod_tipo_moneda", StringType(), True),
            StructField("cod_naturaleza", StringType(), True),
            StructField("cod_indicador_balance", StringType(), True),
            StructField("cod_indicador_resultado", StringType(), True),
            StructField("tiene_centro_costo", StringType(), True),
            StructField("tiene_cuenta_auxiliar", StringType(), True),
            StructField("cod_tipo_cuenta_auxiliar", StringType(), True),
            StructField("tiene_ifrs", StringType(), True),
            StructField("cod_cuenta_contable_corp", StringType(), True),
            StructField("desc_cuenta_contable_corp", StringType(), True),
            StructField("flg_tipres", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_plan_cuentas_corporativo"] = StructType([
            StructField("id_cuenta_contable_corp", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_cuenta_contable_corporativa", StringType(), True),
            StructField("desc_cuenta_contable_corporativa", StringType(), True),
            StructField("cod_cuenta_abono", StringType(), True),
            StructField("cod_cuenta_cargo", StringType(), True),
            StructField("cod_naturaleza", StringType(), True),
            StructField("cod_indicador_balance", StringType(), True),
            StructField("cod_indicador_resultado", StringType(), True),
            StructField("cod_indicador_rubro", StringType(), True),
            StructField("cod_tipo_moneda", StringType(), True),
            StructField("tiene_cuenta_auxiliar", StringType(), True),
            StructField("cod_tipo_cuenta_auxiliar", StringType(), True),
            StructField("tiene_analitic", StringType(), True),
            StructField("es_enlace", StringType(), True),
            StructField("tiene_centro_costo", StringType(), True),
            StructField("tiene_unidad_negocio", StringType(), True),
            StructField("tiene_sku", StringType(), True),
            StructField("tiene_marca", StringType(), True),
            StructField("tiene_categoria", StringType(), True),
            StructField("tiene_canal", StringType(), True),
            StructField("tiene_orden", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", TimestampType(), True),
            StructField("fecha_modificacion", TimestampType(), True)
        ])
        self.dts_schemas["m_clasificacion_cuenta_contable_cogs"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_clasificacion_cuenta_contable_cogs", StringType(), True),
            StructField("id_ejercicio", StringType(), True),
            StructField("id_cuenta_contable", StringType(), True),
            StructField("id_clasificacion_cogs", StringType(), True),
            StructField("cod_ejercicio", StringType(), True),
            StructField("cod_cuenta_contable", StringType(), True),
            StructField("cod_clasificacion_cogs", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["m_clasificacion_cogs"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_clasificacion_cogs", StringType(), True),
            StructField("cod_clasificacion_cogs", StringType(), True),
            StructField("desc_clasificacion_cogs_esp", StringType(), True),
            StructField("desc_clasificacion_cogs_ing", StringType(), True),
            StructField("estado", StringType(), True),
            StructField("fecha_creacion", DateType(), True),
            StructField("fecha_modificacion", DateType(), True)
        ])
        self.dts_schemas["t_voucher_resumen"] = StructType([
            StructField("id_pais", StringType(), True),
            StructField("id_compania", StringType(), True),
            StructField("id_sucursal", StringType(), True),
            StructField("id_periodo", StringType(), True),
            StructField("id_periodo_contable", StringType(), True),
            StructField("id_cuenta_contable", StringType(), True),
            StructField("id_centro_costo", StringType(), True),
            StructField("debe_mn", StringType(), True),
            StructField("debe_me", StringType(), True),
            StructField("haber_mn", StringType(), True),
            StructField("haber_me", StringType(), True),
            StructField("cod_tipo_gasto_cds", StringType(), True),
            StructField("id_tipo_gasto_cds", StringType(), True),
            StructField("cod_clasificacion_pl", StringType(), True),
            StructField("id_clasificacion_pl", StringType(), True)
        ])

        
    def get_schema(self, table_name):
        if table_name in self.dts_schemas:
            return self.dts_schemas[table_name]
        else:
            self.logger(f"{table_name} schema not found")
            return None

class SchemaModeloCadena:
    def __init__(self, logger):
        self.logger = logger
        self.dts_schemas = {}

        self.dts_schemas["dim_articulo"] = StructType(
            [
                StructField("id_articulo", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_articulo_corp", StringType(), True),
                StructField("id_articulo_ext", StringType(), True),
                StructField("cod_articulo", StringType(), True),
                StructField("cod_articulo_corp", StringType(), True),
                StructField("cod_articulo_ext", StringType(), True),
                StructField("desc_articulo_corp", StringType(), True),
                StructField("desc_articulo", StringType(), True),
                StructField("cod_categoria", StringType(), True),
                StructField("desc_categoria", StringType(), True),
                StructField("cod_marca", StringType(), True),
                StructField("desc_marca", StringType(), True),
                StructField("cod_formato", StringType(), True),
                StructField("desc_formato", StringType(), True),
                StructField("cod_sabor", StringType(), True),
                StructField("desc_sabor", StringType(), True),
                StructField("cod_presentacion", StringType(), True),
                StructField("desc_presentacion", StringType(), True),
                StructField("cod_tipo_envase", StringType(), True),
                StructField("desc_tipo_envase", StringType(), True),
                StructField("cod_aroma", StringType(), True),
                StructField("desc_aroma", StringType(), True),
                StructField("cod_gasificado", StringType(), True),
                StructField("desc_gasificado", StringType(), True),
                StructField("cod_linea", StringType(), True),
                StructField("desc_linea", StringType(), True),
                StructField("flg_explosion", StringType(), True),
                StructField("cod_familia", StringType(), True),
                StructField("desc_familia", StringType(), True),
                StructField("cod_subfamilia", StringType(), True),
                StructField("desc_subfamilia", StringType(), True),
                StructField("cod_categoria_compra", StringType(), True),
                StructField("desc_categoria_compra", StringType(), True),
                StructField("cod_subcategoria_compra", StringType(), True),
                StructField("desc_subcategoria_compra", StringType(), True),
                StructField("cod_subcategoria2_compra", StringType(), True),
                StructField("desc_subcategoria2_compra", StringType(), True),
                StructField("cod_unidad_global", StringType(), True),
                StructField("cod_unidad_compra", StringType(), True),
                StructField("cod_unidad_manejo", StringType(), True),
                StructField("cod_unidad_volumen", StringType(), True),
                StructField("cant_unidad_peso", DecimalType(38,12), True),
                StructField("cant_unidad_volumen", DecimalType(38,12), True),
                StructField("cant_unidad_paquete", DecimalType(38,12), True),
                StructField("cant_paquete_caja", DecimalType(38,12), True),
                StructField("flgskuplan", StringType(), True),
            ]
        )
        self.dts_schemas["dim_proveedor"] = StructType(
            [
                StructField("id_proveedor", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("cod_proveedor", StringType(), True),
                StructField("nomb_proveedor", StringType(), True),
                StructField("ruc_proveedor", StringType(), True),
                StructField("desc_estado", StringType(), True)
            ]
        )
        self.dts_schemas["dim_almacen"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_compania", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_almacen", StringType(), True),
                StructField("cod_almacen", StringType(), True),
                StructField("desc_almacen", StringType(), True),
                StructField("desc_tipo_almacen", StringType(), True),
            ]
        )
        self.dts_schemas["dim_motivo_parada"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_motivo_parada_produccion", StringType(), True),
                StructField("cod_parada", StringType(), True),
                StructField("desc_tipo_envio", StringType(), True),
                StructField("cod_correlativo", StringType(), True),
                StructField("desc_motivo", StringType(), True),
                StructField("desc_motivo_detalle", StringType(), True),
                StructField("desc_clasificacion", StringType(), True),
            ]
        )
        self.dts_schemas["dim_linea_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_linea_produccion", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("cod_familia_equipo", StringType(), True),
                StructField("cod_linea_produccion", StringType(), True),
                StructField("desc_familia_equipo", StringType(), True),
                StructField("desc_linea_produccion", StringType(), True),
                StructField("estado", StringType(), True),
            ]
        )
        self.dts_schemas["dim_turno_produccion"] = StructType(
            [
                StructField("id_turno", StringType(), True),
                StructField("id_pais", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("cod_turno", StringType(), True),
                StructField("desc_turno", StringType(), True),
            ]
        )
        self.dts_schemas["fact_compra_rendimiento"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("fecha_rendimiento", DateType(), True),
                StructField("cant_consumida", DoubleType(), True),
                StructField("cant_producida", DoubleType(), True),
                StructField("precio_std_me", DoubleType(), True),
            ]
        )
        self.dts_schemas["fact_compra_ingresada"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("fecha_ingreso_almacen", DateType(), True),
                StructField("nro_orden_compra", StringType(), True),
                StructField("cod_unidad_compra", StringType(), True),
                StructField("cod_unidad_almacen", StringType(), True),
                StructField("cant_compra", DoubleType(), True),
                StructField("cant_almacen", DoubleType(), True),
                StructField("cant_almacen_global", DoubleType(), True),
                StructField("precio_orden_mo", DoubleType(), True),
                StructField("precio_orden_me", DoubleType(), True),
                StructField("precio_orden_mn", DoubleType(), True),
                StructField("precio_ingreso_mo", DoubleType(), True),
                StructField("precio_ingreso_me", DoubleType(), True),
                StructField("precio_ingreso_mn", DoubleType(), True),
                StructField("precio_std_me", DoubleType(), True),
                StructField("imp_compra_ingreso_mo", DoubleType(), True),
                StructField("imp_compra_ingreso_me", DoubleType(), True),
                StructField("imp_compra_ingreso_mn", DoubleType(), True),
                StructField("imp_compra_std_me", DoubleType(), True),
            ]
        )
        self.dts_schemas["fact_evaluacion_proveedores"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_proveedor", StringType(), True),
                StructField("cod_tipo_documento", StringType(), True),
                StructField("nro_orden_compra", StringType(), True),
                StructField("fecha_emision", DateType(), True),
                StructField("nro_secuencia", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("fecha_entrega", DateType(), True),
                StructField("fecha_ingreso_almacen", DateType(), True),
                StructField("cant_perdida", DecimalType(38,12), True),
                StructField("cant_atendida", DecimalType(38,12), True),
                StructField("cant_ingresada", DecimalType(38,12), True),
                StructField("cant_cancelada", DecimalType(38,12), True),
                StructField("es_cancelado", IntegerType(), True),
                StructField("cant_pendiente", DecimalType(38,12), True),
                StructField("es_anulado", IntegerType(), True),
                StructField("es_aprobado", IntegerType(), True),
                StructField("desc_tipo_orden", StringType(), True),
                StructField("imp_neto_mo", DecimalType(38,12), True),
                StructField("imp_compra_mo", DecimalType(38,12), True),
                StructField("imp_neto_me", DecimalType(38,12), True),
                StructField("desc_estado_orden_compra", StringType(), True),
                StructField("es_atendido", IntegerType(), True),
            ]
        )
        self.dts_schemas["fact_orden_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("fecha_liquidacion", DateType(), True),
                StructField("nro_operacion", StringType(), True),
                StructField("precio_cpm_mn", DoubleType(), True),
                StructField("precio_cpm_me", DoubleType(), True),
                StructField("precio_std_mn", DoubleType(), True),
                StructField("precio_std_me", DoubleType(), True),
                StructField("cant_girada", DoubleType(), True),
                StructField("cant_girada_global", DoubleType(), True),
                StructField("imp_girada_mn", DoubleType(), True),
                StructField("imp_girada_me", DoubleType(), True),
                StructField("imp_ingreso_mn", DoubleType(), True),
                StructField("imp_ingreso_me", DoubleType(), True),
            ]
        )
        self.dts_schemas["fact_produccion"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_orden_produccion", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("id_linea_produccion", StringType(), True),
                StructField("id_turno_produccion", StringType(), True),
                StructField("fecha_produccion", DateType(), True),
                StructField("nro_operacion", StringType(), True),
                StructField("cod_avail", StringType(), True),
                StructField("cant_cajafisica_programada", DecimalType(38,12), True),
                StructField("cant_cajafisica_producida", DecimalType(38,12), True),
                StructField("cant_cajafisica_plan", DecimalType(38,12), True),
                StructField("cant_consumo_jarabe_real", DecimalType(38,12), True),
                StructField("cant_jornada_laboral", DecimalType(38,12), True),
                StructField("cant_paradas_por_linea", DecimalType(38,12), True),
                StructField("cant_paradas_ajena_linea", DecimalType(38,12), True),
                StructField("cant_tiempo_ideal", DecimalType(38,12), True),
                StructField("cant_velocidad", DecimalType(38,12), True),
                StructField("cant_velocidad_por_hora", DecimalType(38,12), True),
                StructField("cant_unidades_fabricada", DecimalType(38,12), True),
                StructField("cant_volumen_fabricado", DecimalType(38,12), True),
                StructField("cant_consumo_estandar_jarabe", DecimalType(38,12), True),
                StructField("cant_consumo_estandar_azucar", DecimalType(38,12), True),
                StructField("cant_consumo_estandar_co2", DecimalType(38,12), True),
                StructField("cant_volumen_por_tonelada", DecimalType(38,12), True),
                StructField("cant_pallets", DecimalType(38,12), True),
                StructField("cant_absoluto", DecimalType(38,12), True),
                StructField("cant_consumo_real_azucar", DecimalType(38,12), True),
                StructField("cant_unidades_por_velocidad", DecimalType(38,12), True),
                StructField("cant_cajafisica_fabricada", DecimalType(38,12), True),
                StructField("cant_consumo_standar_batch_jarabe", DecimalType(38,12), True),
                StructField("cant_volumen_programado", DecimalType(38,12), True),
                StructField("cant_volumen_velocidad", DecimalType(38,12), True),
            ]
        )
        self.dts_schemas["fact_movimiento_inventario_diario"] = StructType(
            [
                StructField("id_pais", StringType(), True),
                StructField("id_periodo", StringType(), True),
                StructField("id_sucursal", StringType(), True),
                StructField("id_almacen", StringType(), True),
                StructField("id_articulo", StringType(), True),
                StructField("fecha_ini_movimiento", DateType(), True),
                StructField("fecha_fin_movimiento", DateType(), True),
                StructField("cod_unidad_manejo", StringType(), True),
                StructField("precio_unitario_mn", DoubleType(), True),
                StructField("precio_unitario_me", DoubleType(), True),
                StructField("cant_unidades_inicial", DoubleType(), True),
                StructField("cant_unidades_ingreso", DoubleType(), True),
                StructField("cant_unidades_salida", DoubleType(), True),
                StructField("cant_unidades_saldo", DoubleType(), True),
                StructField("cant_cajas_saldo", DoubleType(), True),
                StructField("imp_valorizado_mn", DoubleType(), True),
                StructField("imp_valorizado_me", DoubleType(), True),
                StructField("cant_unidades", DoubleType(), True),
                StructField("cant_unidades_volumen", DoubleType(), True),
                StructField("imp_saldo_inicial", DoubleType(), True),
                StructField("imp_saldo_final", DoubleType(), True),
                StructField("imp_valorizado_ingreso", DoubleType(), True),
                StructField("imp_valorizado_salida", DoubleType(), True),
                StructField("imp_costo_promedio_mensual", DoubleType(), True),
                StructField("cant_unidades_transito", DoubleType(), True),
                StructField("imp_transito_mn", DoubleType(), True),
                StructField("imp_transito_me", DoubleType(), True),
            ]
        )
    def get_schema(self, table_name):
        if table_name in self.dts_schemas:
            return self.dts_schemas[table_name]
        else:
            self.logger(f"{table_name} schema not found")
            return None
